module.exports = {
  apps: [
    {
      name: "anya-md",
      script: "main.js",
      node_args: "--max-old-space-size=512 --expose-gc",
      exec_mode: "fork",
      instances: 1,
      max_memory_restart: "500M",
      autorestart: true,
      watch: false,
      restart_delay: 3000,
      env: {
        NODE_ENV: "production"
      }
    }
  ]
};
