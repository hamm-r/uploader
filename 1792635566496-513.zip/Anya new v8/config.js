import { watchFile, unwatchFile } from 'fs';
import chalk from 'chalk';
import { fileURLToPath } from 'url';

global.owner = [['628xxx', 'hamm', true]];
global.mods = ['628xxx'];
global.nomorbot = '628xxx';
global.self = false;

global.namebot = '𝐀𝐧𝐲𝐚 𝐚𝐢 𝐛𝐲 𝐡𝐚𝐦𝐦';
global.author = 'Hamm';


// =========================
// 🌐 AUTO TRANSLATE
// =========================
// Bahasa asli plugin Anya = Indonesia.
// Per chat bisa diganti dengan:
// .lang id
// .lang en
global.autoTranslate = {
    enabled: true,
    source: 'id',
    defaultLanguage: 'id',
    engine: 'google'
};

// JANGAN DI UBAH 
global.ownerNumber = global.owner?.[0]?.[0] || '';
global.ownerName = global.owner?.[0]?.[1] || 'Owner';

// =========================
// UI & MEDIA CONFIG
// =========================
global.images = {
    // Ukuran memanjang / Banner (16:9)
    ratio_16_9: {
        url: 'https://raw.githubusercontent.com/hamm-r/uploader/main/1789205208777-641.jpg',
        width: 1080,
        height: 369 
    },
    // Ukuran persegi / Profile (1:1)
    ratio_1_1: {
        url: 'https://raw.githubusercontent.com/hamm-r/uploader/main/1789205442960-756.jpg',
        url_fallback: 'https://raw.githubusercontent.com/hamm-r/uploader/main/1789205442960-756.jpg'
    }
};

global.ownerInfo = {
    title: 'Hamm',
    subtitle: 'Developer of ❀ ᴀɴʏᴀ ᴍᴅ ❀',
    secondary_subtitle: 'editor',
    entity_id: 867051314767696,
    entity_url: 'https://whatsapp.com/channel/0029VbDvzjlDzgTJY34zxT1H'
};

// =========================
// BACKUP CONFIG
// =========================
global.backupGroupLink = '120363410806946879@g.us' // Masukkan JID grup backup kamu di sini

// =========================
// 🔒 ONLYGC CONFIG
// =========================
global.onlygc = {
    enabled: false,
    groups: [
        '120363428453032815@g.us'//ubah pake grup kamu pake idgc
    ]
}

global.wait = '✨ _Wait..._';
global.eror = '🚩 Terjadi Kesalahan...';

global.pakasir = {
	slug: 'hilman',
	apikey: 'ambil di web',
	expired: 30,
};

global.stickpack = 'Sticker';
global.stickauth = namebot;

global.multiplier = 38;

/*============== PANEL ==============*/
global.panel = {
  domain: "https://bokepytta.com",
  ptla: "ptla_xxxxxxxxx",
  ptlc: "ptlc_xxxxxxxxx",
  egg: 15,
  loc: 1
};

global.APIs = {
    faa: 'https://api-faa.my.id',
    deline: 'https://api.deline.web.id',
    kyzz: 'https://api.kyzzz.xyz'
};

global.APIKeys = {
    'https://api.kyzzz.xyz': 'ambil aja sendiri'
};

global.API = (name, path = '/', query = {}, apikeyqueryname) => {
    const baseUrl = name in global.APIs ? global.APIs[name] : name;
    const q = { ...query };

    if (apikeyqueryname) {
        const key = global.APIKeys[baseUrl] || global.APIKeys[name];
        if (key) q[apikeyqueryname] = key;
    }

    const search = new URLSearchParams(q).toString();
    return baseUrl + path + (search ? '?' + search : '');
};

/*============== EMOJI ==============*/
global.rpg = {
	emoticon(string) {
		string = string.toLowerCase();
		let emot = {
			level: '📊',
			limit: '🎫',
			health: '❤️',
			stamina: '🔋',
			exp: '✨',
			money: '💹',
			bank: '🏦',
			potion: '🥤',
			diamond: '💎',
			common: '📦',
			uncommon: '🛍️',
			mythic: '🎁',
			legendary: '🗃️',
			superior: '💼',
			pet: '🔖',
			trash: '🗑',
			armor: '🥼',
			sword: '⚔️',
			pickaxe: '⛏️',
			fishingrod: '🎣',
			wood: '🪵',
			rock: '🪨',
			string: '🕸️',
			horse: '🐴',
			cat: '🐱',
			dog: '🐶',
			fox: '🦊',
			petFood: '🍖',
			iron: '⛓️',
			gold: '🪙',
			emerald: '❇️',
			upgrader: '🧰',
		};
		let results = Object.keys(emot)
			.map((v) => [v, new RegExp(v, 'gi')])
			.filter((v) => v[1].test(string));
		if (!results.length) return '';
		else return emot[results[0][0]];
	},
};

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
	unwatchFile(file);
	console.log(chalk.redBright("Update 'config.js'"));
	import(`${file}?update=${Date.now()}`);
});