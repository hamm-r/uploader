/**
 * Elysia AI — WhatsApp Bot
 *
 * Library      : @wishkeysocket/baileys
 * Type         : Plugins | ESM Modules
 * Creator      : sahril2nd
 * Recode       : (Your Name)
 *
 * Official Channels:
 * • https://whatsapp.com/channel/0029Vb8nqcVCHDypfSfySZ29
 *
 * Documentation:
 * [ID]  Baca README.md untuk melihat panduan.
 * [EN]  Read README.md untuk melihat panduan.
 *
 * Distribution Notice:
 * Dilarang menyebarkan source code ini secara gratis
 * tanpa izin dari creator.
 *
 * Pelanggaran terhadap ketentuan ini dapat menyebabkan
 * penghentian update dan dukungan terhadap source code.
 *
 * Copyright © sahril2nd 2026
 * All Rights Reserved.
 */

import fs from 'fs'

const handler = async (m, { conn, args, usedPrefix, command }) => {
    if (m.isBaileys)
        return m.reply('ngapain 😂?')

    const example = () =>
        `Contoh:\n${usedPrefix + command} 6281234567890\n\n` +
        `Atau reply/tag orang yang ingin dihapus dari owner.`

    let targetJid = null

    // 1. Dari nomor
    if (args[0]) {
        const clean = args[0].replace(/[^0-9]/g, '')

        if (!clean)
            return m.reply(example())

        targetJid = clean + '@s.whatsapp.net'

    // 2. Dari reply
    } else if (m.quoted?.sender) {
        targetJid = m.quoted.sender

    // 3. Dari tag
    } else if (m.mentionedJid?.[0]) {
        targetJid = m.mentionedJid[0]
    }

    if (!targetJid)
        return m.reply(example())

    const normalize = jid =>
        String(jid || '')
            .split('@')[0]
            .split(':')[0]
            .replace(/[^0-9]/g, '')

    const targetNumber = normalize(targetJid)

    if (!targetNumber)
        return m.reply('❌ Nomor owner tidak valid.')

    const isMain = (global.owner || []).some(
        v => normalize(Array.isArray(v) ? v[0] : v) === targetNumber
    )
    if (isMain) {
        return m.reply('❌ Tidak bisa menghapus owner utama dari config/global.')
    }

    if (!Array.isArray(global.db.owners)) {
        global.db.data.owners = []
    }

    const index = global.db.owners.findIndex(owner => {
        const ownerNumber = normalize(Array.isArray(owner) ? owner[0] : owner)
        return ownerNumber === targetNumber
    })

    if (index === -1) {
        return m.reply(
            `❌ Nomor ${targetNumber} tidak ditemukan di database owner.`
        )
    }

    const removed = global.db.owners[index]
    global.db.owners.splice(index, 1)
    await global.db.write()

    return m.reply(
        `✅ Berhasil menghapus owner dari database.\n\n` +
        `👤 Nama: ${Array.isArray(removed) ? (removed[1] || 'Owner') : 'Owner'}\n` +
        `📱 Nomor: ${targetNumber}`
    )
}

handler.command = ['delown', 'delowner']
handler.owner = true
handler.noJadiBot = true
handler.mainOwner = true

export default handler