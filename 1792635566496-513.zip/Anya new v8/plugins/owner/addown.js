/**
 * Elysia AI — WhatsApp Bot
 *
 * Library      : @wishkeysocket/baileys
 * Type         : Plugins | ESM Modules
 * Creator      : sahril2nd
 * Recode       : (Your Name)
 *
 * Official Channels:
 * • https://whatsapp.com/channel/0029Vb8nqcVCHDypfSfySZ29
 *
 * Copyright © sahril2nd 2026
 * All Rights Reserved.
 */

import fs from 'fs'

const handler = async (
    m,
    {
        conn,
        args,
        usedPrefix,
        command
    }
) => {
    if (m.isBaileys) return m.reply('ngapain 😂?')

    const example = () => {
        return `Contoh:
${usedPrefix + command} 6281234567890

Atau:
- Reply pesan orang
- Tag orang`
    }

    let targetJid = null

    // Nomor
    if (args?.[0]) {
        const clean = args[0].replace(/[^0-9]/g, '')

        if (!clean) return m.reply(example())

        targetJid = clean + '@s.whatsapp.net'

    // Reply
    } else if (m.quoted?.sender) {
        targetJid = m.quoted.sender

    // Tag
    } else if (m.mentionedJid?.[0]) {
        targetJid = m.mentionedJid[0]
    }

    if (!targetJid) {
        return m.reply(example())
    }

    const isLid = targetJid.endsWith('@lid')

    // Cek nomor WhatsApp
    if (!isLid) {
        const check = await conn
            .onWhatsApp(targetJid)
            .catch(() => [])

        if (!check?.length) {
            return m.reply(
                'Masukkan nomor yang valid dan terdaftar di WhatsApp!'
            )
        }
    }

    const norm = jid => {
        if (!jid) return ''
        return String(jid)
            .split('@')[0]
            .split(':')[0]
            .replace(/[^0-9]/g, '')
    }

    const isMain = (global.owner || []).some(
        v => norm(Array.isArray(v) ? v[0] : v) === norm(targetJid)
    )
    if (isMain) {
        return m.reply('Nomor sudah menjadi owner utama (global.owner).')
    }

    if (!Array.isArray(global.db.owners)) {
        global.db.data.owners = []
    }

    const exists = global.db.owners.some(
        v => norm(Array.isArray(v) ? v[0] : v) === norm(targetJid)
    )
    if (exists) {
        return m.reply('Nomor sudah ada di database owner.')
    }

    const ownerName = 'Owner'
    global.db.owners.push([
        norm(targetJid),
        ownerName,
        false
    ])
    await global.db.write()

    return m.reply(`Berhasil menambahkan ${norm(targetJid)} ke database owner.`)
}

handler.command = ['addown', 'addowner']
handler.owner = true
handler.noJadiBot = true
handler.mainOwner = true

export default handler