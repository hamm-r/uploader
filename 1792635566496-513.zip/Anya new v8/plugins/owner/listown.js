/** 
 * Elysia AI — WhatsApp Bot 
 * 
 * Library : @wishkeysocket/baileys 
 * Type    : Plugins | ESM Modules 
 * Creator : sahril2nd 
 * Recode  : Hamm 
 * 
 * Official Channels: 
 * • https://whatsapp.com/channel/0029Vb8nqcVCHDypfSfySZ29 
 * 
 * Documentation: 
 * [ID] Baca README.md untuk melihat panduan. 
 * [EN] Read README.md untuk melihat panduan. 
 * 
 * Distribution Notice: 
 * Dilarang menyebarkan source code ini secara gratis 
 * tanpa izin dari creator. 
 * 
 * Copyright © sahril2nd 2026 
 * All Rights Reserved. 
 */ 

const handler = async (m, { conn }) => { 
  if (m.isBaileys) return m.reply('ngapain 😂?') 
  
  const mainOwners = Array.isArray(global.owner) 
    ? global.owner
        .map(v => (Array.isArray(v) ? v[0] : v))
        .filter(Boolean) 
    : [] 

  const dbOwners = Array.isArray(global.db?.owners)
    ? global.db.owners
        .map(v => (Array.isArray(v) ? v[0] : v))
        .filter(Boolean)
    : []

  if (!mainOwners.length && !dbOwners.length) { 
    return m.reply('Tidak ada owner yang terdaftar.') 
  } 
  
  let teks = '*List Owner*:\n\n' 
  
  if (mainOwners.length) {
    teks += '👑 *Owner Utama (Global)*:\n'
    for (const number of mainOwners) { 
      const jid = String(number).includes('@') 
        ? String(number) 
        : `${String(number).replace(/\D/g, '')}@s.whatsapp.net` 
      const nomor = jid.split('@')[0] 
      teks += `* ${nomor} (@${nomor})\n` 
    }
    teks += '\n'
  }

  if (dbOwners.length) {
    teks += '👤 *Owner Tambahan (Database)*:\n'
    for (const number of dbOwners) { 
      const jid = String(number).includes('@') 
        ? String(number) 
        : `${String(number).replace(/\D/g, '')}@s.whatsapp.net` 
      const nomor = jid.split('@')[0] 
      teks += `* ${nomor} (@${nomor})\n` 
    }
  }

  const allOwners = [...mainOwners, ...dbOwners]
  await conn.sendMessage( 
    m.chat, 
    { 
      text: teks.trim(), 
      mentions: allOwners.map(v => 
        String(v).includes('@') 
          ? String(v) 
          : `${String(v).replace(/\D/g, '')}@s.whatsapp.net` 
      ) 
    }, 
    { quoted: m } 
  ) 
} 

handler.command = ['listown', 'listowner'] 
handler.owner = true 
handler.noJadiBot = true 
handler.mainOwner = true 

export default handler