/**
* ONLYGC SYSTEM — ANYA MD
* Creator: Hamm
  */

let handler = async (m, { args }) => {
const owners = [
...(global.owner || []).map(v =>
Array.isArray(v) ? v[0] : v
),
...(Array.isArray(global.db?.owners)
? global.db.owners.map(v =>
Array.isArray(v) ? v[0] : v
)
: [])
].map(v => String(v || '').replace(/\D/g, ''))

const senderNumber = String(m.sender || '')
    .split('@')[0]
    .replace(/\D/g, '')

const isOwner =
    m.fromMe || owners.includes(senderNumber)

if (!isOwner) {
    return m.reply('🚫 Command ini khusus owner bot!')
}

// Inisialisasi database settings
if (!global.db.data) {
    global.db.data = {}
}

if (!global.db.data.settings) {
    global.db.data.settings = {}
}

// Inisialisasi konfigurasi ONLYGC
if (!global.onlygc) {
    global.onlygc = {
        enabled: false,
        groups: []
    }
}

const settings = global.db.data.settings
const action = String(args[0] || 'status').toLowerCase()

if (!['on', 'off', 'status'].includes(action)) {
    return m.reply(
        'Penggunaan:\n' +
        '• .onlygc on\n' +
        '• .onlygc off\n' +
        '• .onlygc status'
    )
}

// Aktifkan atau nonaktifkan ONLYGC
if (action === 'on' || action === 'off') {
    const enabled = action === 'on'

    settings.onlygcEnabled = enabled
    global.onlygc.enabled = enabled

    // Simpan ke database jika API tersedia
    try {
        if (typeof global.db.write === 'function') {
            await global.db.write()
        } else if (typeof global.db.save === 'function') {
            await global.db.save()
        }
    } catch (e) {
        console.error('[ONLYGC] Gagal menyimpan status:', e)
        return m.reply(
            '⚠️ Status berubah, tetapi gagal menyimpan database.'
        )
    }

    return m.reply(
        `${enabled ? '🔒' : '🔓'} *ONLYGC ${enabled ? 'AKTIF' : 'NONAKTIF'}*\n\n` +
        `Status: ${enabled ? 'Aktif ✅' : 'Nonaktif ❌'}\n` +
        `Grup diizinkan: ${(global.onlygc.groups || []).length}\n\n` +
        'Status tersimpan jika database mendukung metode penyimpanan yang digunakan.'
    )
}

// Tampilkan status
const groups = Array.isArray(global.onlygc.groups)
    ? global.onlygc.groups
    : []

return m.reply(
    `🔒 *ONLYGC STATUS*\n\n` +
    `Status: ${settings.onlygcEnabled ? 'AKTIF ✅' : 'NONAKTIF ❌'}\n` +
    `Grup diizinkan: ${groups.length}\n\n` +
    `• .onlygc on\n` +
    `• .onlygc off\n` +
    `• .onlygc status`
)

}

handler.help = ['onlygc <on/off/status>']
handler.tags = ['owner']
handler.command = /^onlygc$/i
handler.owner = true

export default handler