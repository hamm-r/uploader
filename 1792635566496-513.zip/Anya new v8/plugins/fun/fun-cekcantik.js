import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js'

let handler = async (m, { conn, sock }) => {
  const client = conn || sock
  if (typeof global.react === 'function') await global.react(client, m, 'loading')

  const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  const name = (client.getName ? await client.getName(who) : null) || `@${who.split('@')[0]}`
  const avatarBuffer = await getAvatarBuffer(client, who)

  const score = Math.floor(Math.random() * 101)
  let verdict = ''

  if (score < 20) verdict = 'Buriq banget astaga, muka apa sendal jepit? 😭'
  else if (score < 40) verdict = 'Mending buruan cuci muka pake air wudhu deh~ 🙈'
  else if (score < 60) verdict = 'Lumayan manis tipis-tipis kalau dilihat dari kejauhan! ✨'
  else if (score < 80) verdict = 'Cantik gemes, bikin cowok-cowok pada salfok! 💖'
  else verdict = 'MasyaAllah cantiknya bidadari kayangan turun ke bumi! 🌸✨'

  const canvasBuffer = await renderCekCanvas({
    title: '🌸 CEK CANTIK 🌸',
    name: `@${who.split('@')[0]}`,
    score: `${score}%`,
    ratingText: verdict,
    avatarBuffer,
    emoji: '👸'
  })

  await client.sendMessage(
    m.chat,
    {
      image: canvasBuffer,
      caption: `🌸 *HASIL CEK CANTIK*\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Tingkat Cantik:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
      mentions: [who]
    },
    { quoted: m }
  )

  if (typeof global.react === 'function') await global.react(client, m, 'success')
}

handler.help = ['cekcantik']
handler.tags = ['fun']
handler.command = /^(cekcantik|cantikcek)$/i
handler.limit = true
handler.register = true

export default handler