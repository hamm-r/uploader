import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js';

let handler = async (m, { conn, sock }) => {
	const client = conn || sock;
	if (typeof global.react === 'function') await global.react(client, m, 'loading');

	const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
	const avatarBuffer = await getAvatarBuffer(client, who);

	const score = Math.floor(Math.random() * 101);
	let verdict = '';

	if (score < 20) verdict = 'Manusia normal, gak pernah nonton anime! 🚶';
	else if (score < 40) verdict = 'Cuma tau Naruto sama One Piece doang~ 🍙';
	else if (score < 60) verdict = 'Suka dengerin lagu jepang dan koleksi waifu! 🎧';
	else if (score < 80) verdict = 'Bau bawang akut, tiap hari halu sama karakter anime! 🧅';
	else verdict = 'WIBU SEJATI NOMOR SATU, IKZUUU SASAGEYO ONII-CHAN! 🎌✨';

	const canvasBuffer = await renderCekCanvas({
		title: '🌸 CEK LEVEL WIBU 🌸',
		name: `@${who.split('@')[0]}`,
		score: `${score}%`,
		ratingText: verdict,
		avatarBuffer,
		emoji: '🎎'
	});

	await client.sendMessage(
		m.chat,
		{
			image: canvasBuffer,
			caption: `🌸 CEK LEVEL WIBU 🌸\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Hasil:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
			mentions: [who]
		},
		{ quoted: m }
	);

	if (typeof global.react === 'function') await global.react(client, m, 'success');
};

handler.help = ['cekwibu'];
handler.tags = ['fun'];
handler.command = /^(cekwibu)$/i;
handler.limit = true;
handler.register = true;

export default handler;
