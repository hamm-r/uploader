import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js';

let handler = async (m, { conn, sock }) => {
	const client = conn || sock;
	if (typeof global.react === 'function') await global.react(client, m, 'loading');

	const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
	const avatarBuffer = await getAvatarBuffer(client, who);

	const score = Math.floor(Math.random() * 101);
	let verdict = '';

	if (score < 20) verdict = 'Lurus setegak tiang bendera, normal 100%! 🛡️';
	else if (score < 40) verdict = 'Kadang suka muji temen cowok doang sih~ 😅';
	else if (score < 60) verdict = 'Mulai mencurigakan, tatapannya agak beda... 👀';
	else if (score < 80) verdict = 'Sering genit dan nempel-nempel sama cowok lain! 🙈';
	else verdict = 'GAY LEVEL MAKSIMAL, BURUAN TAUBAT MAS! 🌈💥';

	const canvasBuffer = await renderCekCanvas({
		title: '🌈 CEK TINGKAT GAY 🌈',
		name: `@${who.split('@')[0]}`,
		score: `${score}%`,
		ratingText: verdict,
		avatarBuffer,
		emoji: '🏳️‍🌈'
	});

	await client.sendMessage(
		m.chat,
		{
			image: canvasBuffer,
			caption: `🌈 CEK TINGKAT GAY 🌈\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Hasil:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
			mentions: [who]
		},
		{ quoted: m }
	);

	if (typeof global.react === 'function') await global.react(client, m, 'success');
};

handler.help = ['cekgay'];
handler.tags = ['fun'];
handler.command = /^(cekgay)$/i;
handler.limit = true;
handler.register = true;

export default handler;
