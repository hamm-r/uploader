import axios from 'axios';
let handler = async (m) => {
	let result = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/kata-kata/truth.json');
	let truth = result.data.getRandom();
	m.reply(truth);
};

handler.help = ['truth'];
handler.tags = ['fun'];
handler.command = /^(truth)$/i;

handler.register = true

export default handler;
