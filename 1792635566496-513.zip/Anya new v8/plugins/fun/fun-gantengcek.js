import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js'

let handler = async (m, { conn, sock }) => {
  const client = conn || sock
  if (typeof global.react === 'function') await global.react(client, m, 'loading')

  const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  const avatarBuffer = await getAvatarBuffer(client, who)

  const score = Math.floor(Math.random() * 101)
  let verdict = ''

  if (score < 20) verdict = 'Cermin aja auto retak liat muka lo bro! 😭'
  else if (score < 40) verdict = 'Ganteng tipis-tipis, kayak sinyal di pelosok gunung 🙈'
  else if (score < 60) verdict = 'Bolehlah lumayan manis kalau diliat pas lampu mati ✨'
  else if (score < 80) verdict = 'Kharismatik abis, adek-adek gemes auto naksir! 😎'
  else verdict = 'COWOK TERGANTENG SEJAGAT RAYA, OPPA KOREA LEWAT! 🔥👑'

  const canvasBuffer = await renderCekCanvas({
    title: '✨ CEK GANTENG ✨',
    name: `@${who.split('@')[0]}`,
    score: `${score}%`,
    ratingText: verdict,
    avatarBuffer,
    emoji: '🤴'
  })

  await client.sendMessage(
    m.chat,
    {
      image: canvasBuffer,
      caption: `✨ *HASIL CEK GANTENG*\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Tingkat Ganteng:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
      mentions: [who]
    },
    { quoted: m }
  )

  if (typeof global.react === 'function') await global.react(client, m, 'success')
}

handler.help = ['cekganteng']
handler.tags = ['fun']
handler.command = /^(cekganteng|gantengcek)$/i
handler.limit = true
handler.register = true

export default handler
