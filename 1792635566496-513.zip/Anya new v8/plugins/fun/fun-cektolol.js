import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js';

let handler = async (m, { conn, sock }) => {
	const client = conn || sock;
	if (typeof global.react === 'function') await global.react(client, m, 'loading');

	const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
	const avatarBuffer = await getAvatarBuffer(client, who);

	const score = Math.floor(Math.random() * 101);
	let verdict = '';

	if (score < 20) verdict = 'Pinter dan teliti, jauh dari kata tolol! ✨';
	else if (score < 40) verdict = 'Kadang tolol pas panik doang sih~ 😅';
	else if (score < 60) verdict = 'Tingkahnya sering bikin geleng-geleng kepala! 🗿';
	else if (score < 80) verdict = 'Ketololannya sudah di luar nalar manusia normal! 🤯';
	else verdict = 'RAJA TOLOL SEALAM DUNIA, KELAKUANNYA BIKIN EMOSI! 🎭';

	const canvasBuffer = await renderCekCanvas({
		title: '🤡 CEK KETOLOLAN 🤡',
		name: `@${who.split('@')[0]}`,
		score: `${score}%`,
		ratingText: verdict,
		avatarBuffer,
		emoji: '🤡'
	});

	await client.sendMessage(
		m.chat,
		{
			image: canvasBuffer,
			caption: `🤡 CEK KETOLOLAN 🤡\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Hasil:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
			mentions: [who]
		},
		{ quoted: m }
	);

	if (typeof global.react === 'function') await global.react(client, m, 'success');
};

handler.help = ['cektolol'];
handler.tags = ['fun'];
handler.command = /^(cektolol)$/i;
handler.limit = true;
handler.register = true;

export default handler;
