import { generateFunCard } from '../../lib/canvas-fun.js'

const getCleanTag = (jid) => {
  if (!jid) return ''
  return String(jid).split('@')[0].split(':')[0]
}

const DOSA_LIST = [
  'Makan gorengan 5 ngakunya cuma 2 ke abang kang gorengan 🥟',
  'Pura-pura budek pas emak manggil nyuruh beli royco 🙉',
  'Nge-read chat gebetan 3 hari kemudian baru bales "wkwk iya" 💀',
  'Minjem korek api temen tapi langsung masuk kantong celana 🚬',
  'Pura-pura tidur pas temen lagi bagi-bagi tagihan nongkrong 😴',
  'Nyolong wifi tetangga sambil download game 50GB 📶',
  'Stalking akun mantan pake fake account sampai kepencet like postingan 3 tahun lalu 📱',
  'Ngomong "otw" padahal baru bangun tidur masih iler-an 🛵',
  'Ngetik "wkwkwk" di chat padahal mukanya datar kayak triplek 🗿',
  'Balikin piring hajatan tetangga tapi isinya malah remahan biskuit 🍽️'
]

const getTarget = async (m, text, client) => {
  let targetJid = null
  let targetName = ''

  if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetJid = m.mentionedJid[0]
  } else if (m.quoted && m.quoted.sender) {
    targetJid = m.quoted.sender
  } else if (text && text.trim().length > 0) {
    const cleanNum = text.replace(/[^0-9]/g, '')
    if (cleanNum.length >= 7 && cleanNum.length <= 15) {
      targetJid = cleanNum + '@s.whatsapp.net'
    } else {
      targetName = text.trim()
    }
  } else {
    targetJid = m.sender
  }

  let cardName = targetName
  let captionTag = targetName

  if (targetJid) {
    const cleanTag = getCleanTag(targetJid)
    captionTag = `@${cleanTag}`

    if (!cardName) {
      let foundName = null
      try {
        foundName = client.getName ? await client.getName(targetJid) : null
      } catch {}
      if (!foundName && global.db?.data?.users?.[targetJid]?.name) {
        foundName = global.db.data.users[targetJid].name
      }
      if (foundName && foundName !== 'User' && !/^\d+$/.test(foundName)) {
        cardName = foundName
      } else if (targetJid === m.sender && m.pushName) {
        cardName = m.pushName
      } else {
        cardName = `@${cleanTag}`
      }
    }
  }

  return { targetJid, targetName: cardName, captionTag: captionTag || cardName }
}

let handler = async (m, { conn, sock, text }) => {
  const client = conn || sock
  const { targetJid, targetName, captionTag } = await getTarget(m, text, client)

  const dosa = DOSA_LIST[Math.floor(Math.random() * DOSA_LIST.length)]
  const dosaLevel = Math.floor(Math.random() * 50) + 50

  let ppUrl = null
  if (targetJid && client?.profilePictureUrl) {
    try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null) } catch (_) {}
  }

  const cardBuffer = await generateFunCard({
    title: '😈 DETEKTOR DOSA KECIL',
    badgeText: `🔥 ${dosaLevel}% DOSA`,
    titleBg: '#dc2626',
    badgeBg: '#ffea00',
    name: targetName,
    rate: dosaLevel,
    categoryLabel: 'Kategori Pelanggaran',
    categoryValue: 'Dosa Kecil Lucu 🙈',
    descLabel: 'Dosa Terdeteksi',
    descValue: dosa,
    footerText: 'Segera minta maaf & perbaiki kelakuan ya!',
    barColor: '#ef4444',
    ppUrl
  }).catch(() => null)

  const caption = `😈 *DETEKTOR DOSA KECIL* 😈\n\n• 👤 *Pelaku:* ${captionTag}\n• 🔥 *Tingkat Dosa:* *${dosaLevel}%*\n• 📜 *Dosa Terdeteksi:* _"${dosa}"_\n\n_Saran: Segera minta maaf dan tobat ya guys!_ 🙏`

  await client?.sendMessage(m.chat, { react: { text: '😈', key: m.key } }).catch(() => null)

  const mentions = targetJid ? [targetJid] : []
  if (cardBuffer) {
    return client.sendMessage(m.chat, {
      image: cardBuffer,
      caption,
      mentions
    }, { quoted: m })
  } else {
    return client.sendMessage(m.chat, {
      text: caption,
      mentions
    }, { quoted: m })
  }
}

handler.help = ['cekdosa']
handler.tags = ['fun']
handler.command = /^(cekdosa|dosacheck)$/i
handler.limit = true
handler.register = true

export default handler
