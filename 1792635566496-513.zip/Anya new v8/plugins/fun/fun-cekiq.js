import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js'

let handler = async (m, { conn, sock }) => {
  const client = conn || sock
  if (typeof global.react === 'function') await global.react(client, m, 'loading')

  const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  const avatarBuffer = await getAvatarBuffer(client, who)

  const iq = Math.floor(Math.random() * 141) + 60 // 60 - 200
  let verdict = ''

  if (iq < 80) verdict = 'Otak udang, mikir dikit langsung ngebul berasap! 😭'
  else if (iq < 100) verdict = 'Standar manusia bumi kebanyakan, jangan keseringan bengong~'
  else if (iq < 125) verdict = 'Lumayan encer otaknya, cepet paham pelajaran! 💡'
  else if (iq < 150) verdict = 'Cerdas di atas rata-rata, calon ilmuwan sukses! 🧠✨'
  else verdict = 'JENIUS TIDAK WAJAR, EINSTEIN AJA KALAH SUHU! 🚀🔥'

  // Map IQ to 0-100 for progress bar
  const scorePercent = Math.min(100, Math.max(0, Math.round(((iq - 60) / 140) * 100)))

  const canvasBuffer = await renderCekCanvas({
    title: '🧠 CEK TINGKAT IQ 🧠',
    name: `@${who.split('@')[0]}`,
    score: `${iq} IQ`,
    ratingText: verdict,
    avatarBuffer,
    emoji: '🧠'
  })

  await client.sendMessage(
    m.chat,
    {
      image: canvasBuffer,
      caption: `🧠 *HASIL CEK TINGKAT IQ*\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Skor IQ:* *${iq}*\n\n💬 *Penilaian:* _${verdict}_`,
      mentions: [who]
    },
    { quoted: m }
  )

  if (typeof global.react === 'function') await global.react(client, m, 'success')
}

handler.help = ['cekiq']
handler.tags = ['fun']
handler.command = /^cekiq$/i
handler.limit = true
handler.register = true

export default handler