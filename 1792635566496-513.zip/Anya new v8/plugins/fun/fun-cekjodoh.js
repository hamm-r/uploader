import { renderCekCanvas, getAvatarBuffer } from '../../lib/canvas-fun.js';

let handler = async (m, { conn, sock }) => {
	const client = conn || sock;
	if (typeof global.react === 'function') await global.react(client, m, 'loading');

	const who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;
	const avatarBuffer = await getAvatarBuffer(client, who);

	const score = Math.floor(Math.random() * 101);
	let verdict = '';

	if (score < 20) verdict = 'Belum siap sama sekali, mending fokus sekolah/kerja! 🎒';
	else if (score < 40) verdict = 'Masih gamon sama mantan, buka hati dulu ya~ 💔';
	else if (score < 60) verdict = 'Udah siap pacaran tapi masih takut komitmen! 🤝';
	else if (score < 80) verdict = 'Siap dilamar, tinggal nunggu restu orang tua! 💌';
	else verdict = 'JODOH SUDAH DEKAT DI DEPAN MATA, TINGGAL GAS NIKAH! 💍💒';

	const canvasBuffer = await renderCekCanvas({
		title: '💍 CEK KESIAPAN JODOH 💍',
		name: `@${who.split('@')[0]}`,
		score: `${score}%`,
		ratingText: verdict,
		avatarBuffer,
		emoji: '👰'
	});

	await client.sendMessage(
		m.chat,
		{
			image: canvasBuffer,
			caption: `💍 CEK KESIAPAN JODOH 💍\n\n👤 *Target:* @${who.split('@')[0]}\n📊 *Hasil:* *${score}%*\n\n💬 *Penilaian:* _${verdict}_`,
			mentions: [who]
		},
		{ quoted: m }
	);

	if (typeof global.react === 'function') await global.react(client, m, 'success');
};

handler.help = ['cekjodoh'];
handler.tags = ['fun'];
handler.command = /^(cekjodoh)$/i;
handler.limit = true;
handler.register = true;

export default handler;
