import fetch from 'node-fetch'
import { extractTikTokUrl, resolveTikTokUrl } from '../../lib/scrape/tiktok.js'

let handler = async (m, { text, usedPrefix, command, conn }) => {
  try {

    const input = m.quoted ? m.quoted.text : text

    if (!input) {
      return m.reply(
        `Kirim ${usedPrefix + command} url_tiktok`
      )
    }
    await m.reply(wait);

    // Menerima link tiktok.com (www/vm/vt/m, /t/xxx) dan tt.site/t/xxx
    const url = extractTikTokUrl(input)

    if (!url) {
      return m.reply(
        `Link yang kamu berikan tidak valid`
      )
    }

    const data = await getTikTok(url)

    if (!data) {
      return m.reply('TIMEOUT')
    }

    /*
    ============================
        DATA TIKTOK
    ============================
    */

    const nickname =
      data.author?.nickname ||
      data.author?.name ||
      '-'

    const username =
      data.author?.unique_id ||
      data.author?.uniqueId ||
      '-'

    const play =
      data.play_count ||
      data.stats?.playCount ||
      0

    const like =
      data.digg_count ||
      data.like_count ||
      data.stats?.diggCount ||
      0

    const comment =
      data.comment_count ||
      data.stats?.commentCount ||
      0

    const share =
      data.share_count ||
      data.stats?.shareCount ||
      0

    const title =
      data.title ||
      data.desc ||
      '-'
      
    // Mengambil link audio
    const audioUrl = 
      data.music || 
      data.audio || 
      data.music_url || 
      data.music_info?.url

    /*
    ============================
        TIKTOK PHOTO
    ============================
    */

    let images =
      data.images ||
      data.image ||
      data.photo ||
      data.images_url

    if (images && images.length) {

      const caption =
`*[ Tiktok Downloader ]*

• Nickname: ${nickname}
• Username: @${username}
• Type: photo
• Play: ${formatNumber(play)}
• Like: ${formatNumber(like)}
• Comment: ${formatNumber(comment)}
• Share: ${formatNumber(share)}

${title}`

      // Kirim text terlebih dahulu
      await m.reply(caption)

      // Baru kirim gambar sebagai album (otomatis dipecah per 10 foto)
      if (images.length > 1) {
        try {
          await conn.sendAlbum(m.chat, images, { quoted: m })
        } catch (e) {
          console.error('sendAlbum gagal, fallback kirim satuan:', e)
        }
      } else {
        // Fallback / foto tunggal: kirim satu per satu
        for (let i = 0; i < images.length; i++) {
          await conn.sendFile(
            m.chat,
            images[i],
            `tiktok-${i + 1}.jpg`,
            '',
            m
          )
          await delay(1500)
        }
      }

      // Kirim Audio/Music jika ada
      if (audioUrl) {
        await delay(1500)
        await conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg' }, { quoted: m })
      }

      return
    }

    /*
    ============================
        TIKTOK VIDEO
    ============================
    */

    let videoUrl =
      data.play ||
      data.video ||
      data.no_watermark ||
      data.play_url ||
      data.video_url

    if (videoUrl) {

      const caption =
`*[ Tiktok Downloader ]*

• Nickname: ${nickname}
• Username: @${username}
• Type: video
• Play: ${formatNumber(play)}
• Like: ${formatNumber(like)}
• Comment: ${formatNumber(comment)}
• Share: ${formatNumber(share)}

${title}`

      // Video dikirim dengan bar musik (embeddedMusic) seperti contoh
      await sendVideoWithMusic(
        conn,
        m.chat,
        { video: { url: videoUrl }, mimetype: 'video/mp4', caption },
        { quoted: m }
      )

      // Kirim Audio/Music jika ada
      if (audioUrl) {
        await delay(1500)
        await conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mpeg' }, { quoted: m })
      }

      return
    }

    return m.reply('❌ Media TikTok tidak ditemukan.')

  } catch (e) {
    console.error(e)
    return m.reply(
      '❌ Terjadi kesalahan saat download TikTok.'
    )
  }
}

handler.help = ['tiktok']
handler.tags = ['download']
handler.command = /^(tt|ttdl|tiktok)$/i
handler.limit = true

export default handler


// ===============================
// GET TIKTOK WITH FALLBACK
// ===============================

async function getTikTok(url) {
  // Coba link asli dulu; kalau gagal, resolve link pendek (tt.site, vt, vm, /t/) lalu coba lagi.
  let data = await fetchTikTok(url)
  if (data) return data

  const resolved = await resolveTikTokUrl(url)
  if (resolved && resolved !== url) return fetchTikTok(resolved)

  return null
}

async function fetchTikTok(url) {

  // PRIMARY : TIKWM
  try {
    const res = await (
      await fetch(
        `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`
      )
    ).json()

    if (res?.data) {
      return res.data
    }

  } catch {}

  // FALLBACK : SIPUTZX
  try {
    const res = await (
      await fetch(
        `https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`
      )
    ).json()

    if (res?.data) {

      const d = res.data

      return {
        title:
          d.title ||
          d.desc,

        play_count:
          d.stats?.playCount ||
          d.play_count ||
          0,

        digg_count:
          d.stats?.diggCount ||
          d.digg_count ||
          d.like_count ||
          0,

        comment_count:
          d.stats?.commentCount ||
          d.comment_count ||
          0,

        share_count:
          d.stats?.shareCount ||
          d.share_count ||
          0,

        author:
          d.author,

        duration:
          d.duration,

        play:
          d.video ||
          d.no_watermark ||
          d.play,

        images:
          d.images ||
          d.photo ||
          d.images_url,
          
        music: 
          d.music || 
          d.audio || 
          d.music_url || 
          d.music_info?.url
      }
    }

  } catch {}

  return null
}


// ===============================
// FORMAT NUMBER
// ===============================

function formatNumber(num = 0) {
  return Number(num).toLocaleString('en-US')
}


// ===============================
// DELAY
// ===============================

const delay = ms =>
  new Promise(resolve =>
    setTimeout(resolve, ms)
  )


// ===============================
// SEND VIDEO + BAR MUSIK
// ===============================

async function sendVideoWithMusic(conn, jid, content, options = {}) {
  return conn.sendMessage(
    jid,
    {
      ...content,
      streamingSidecar: Buffer.from('Omw4hLediba3yg==', 'base64'),
      annotations: [
        {
          polygonVertices: [
            { x: 0, y: 0 },
            { x: 1000, y: 0 },
            { x: 1000, y: 1000 },
            { x: 0, y: 1000 }
          ],
          shouldSkipConfirmation: true,
          embeddedContent: {
            embeddedMusic: {
              musicContentMediaId: '1409620227516822',
              songId: '244215252974958',
              author: global.author || 'Hamm',
              title: global.namebot || 'Anya MD',
              artistAttribution:
                'https://whatsapp.com/channel/0029VbDvzjlDzgTJY34zxT1H',
              countryBlocklist: '',
              isExplicit: false
            }
          },
          embeddedAction: true
        }
      ]
    },
    options
  )
}