/*
 * Spotify Downloader — ANYA MD
 * Base   : Spotidown.app
 * Type   : Plugin ESM
 * Creator: Hamm
 */

import fetch from 'node-fetch'

const BASE = 'https://spotidown.app'
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'

function parseMetadata(dataVal) {
  try {
    return JSON.parse(Buffer.from(dataVal, 'base64').toString('utf8'))
  } catch {
    return {}
  }
}

async function scrapeSpotify(url) {
  const step1Res = await fetch(`${BASE}/action`, {
    method: 'POST',
    headers: {
      'User-Agent': USER_AGENT,
      'Origin': BASE,
      'Referer': `${BASE}/`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      url,
      'g-recaptcha-response': ''
    })
  })

  const step1Json = await step1Res.json()

  if (!step1Res.ok || step1Json.error) {
    throw new Error(
      step1Json.message ||
      `Gagal mengambil info Spotify (${step1Res.status})`
    )
  }

  const rawCookies = typeof step1Res.headers.getSetCookie === 'function'
    ? step1Res.headers.getSetCookie()
    : [step1Res.headers.get('set-cookie')]

  const cookieHeader = (rawCookies || [])
    .filter(Boolean)
    .map(c => c.split(';')[0])
    .join('; ')

  const html1 = step1Json.data ?? ''

  const dataVal = html1.match(/name="data"\s+value=['"]([^'"]+)['"]/i)?.[1]
  const baseVal = html1.match(/name="base"\s+value=['"]([^'"]+)['"]/i)?.[1]
  const tokenVal = html1.match(/name="token"\s+value=['"]([^'"]+)['"]/i)?.[1]

  if (!dataVal || !tokenVal) {
    throw new Error('Gagal membaca token dari Spotidown.')
  }

  const meta = parseMetadata(dataVal)

  const step2Res = await fetch(`${BASE}/action/track`, {
    method: 'POST',
    headers: {
      'User-Agent': USER_AGENT,
      'Origin': BASE,
      'Referer': `${BASE}/`,
      'Cookie': cookieHeader,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      data: dataVal,
      base: baseVal ?? url,
      token: tokenVal
    })
  })

  const step2Json = await step2Res.json()

  if (!step2Res.ok || step2Json.error) {
    throw new Error(
      step2Json.message ||
      `Gagal membuat link download (${step2Res.status})`
    )
  }

  const html2 = step2Json.data ?? ''

  const mp3Match = html2.match(
    /<a\b[^>]*href=["']([^"']+)["'][^>]*>\s*<span>\s*<span>\s*Download Mp3\s*<\/span>\s*<\/span>/i
  )

  const coverMatch = html2.match(
    /<a\b[^>]*href=["']([^"']+)["'][^>]*>\s*<span>\s*<span>\s*Download Cover[^<]*<\/span>\s*<\/span>/i
  )

  return {
    id: meta.tid ?? null,
    title: meta.name ?? '',
    artist: meta.artist ?? '',
    album: meta.album ?? '',
    duration: meta.duration ?? '',
    releaseYear: meta.date ?? null,
    cover: meta.cover ?? null,
    download: {
      mp3: mp3Match?.[1] ?? null,
      coverHd: coverMatch?.[1] ?? null
    }
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎧 *Spotify Downloader*\n\n` +
      `Masukkan link lagu Spotify!\n\n` +
      `Contoh:\n${usedPrefix + command} https://open.spotify.com/track/ID_LAGU`
    )
  }

  if (!/^https?:\/\/(www\.)?(open\.)?spotify\.com\/(track|intl-[a-z]{2}\/track)\/[a-zA-Z0-9]+/i.test(text.trim())) {
    return m.reply('❌ Link Spotify tidak valid. Kirim link lagu Spotify yang benar.')
  }

  await m.reply('⏳ Tunggu yaa, Anya sedang mengambil data lagunya...')

  try {
    const result = await scrapeSpotify(text.trim())

    if (!result.download.mp3) {
      throw new Error('Link MP3 tidak ditemukan dari Spotidown.')
    }

    const caption =
      `🎧 *SPOTIFY DOWNLOADER*\n\n` +
      `乂 *Judul:* ${result.title || 'Tidak diketahui'}\n` +
      `乂 *Artist:* ${result.artist || 'Tidak diketahui'}\n` +
      `乂 *Album:* ${result.album || 'Tidak diketahui'}\n` +
      `乂 *Durasi:* ${result.duration || 'Tidak diketahui'}\n` +
      `乂 *Rilis:* ${result.releaseYear || 'Tidak diketahui'}\n\n` +
      `❀ ᴀɴʏᴀ ᴍᴅ ❀`

    if (result.cover) {
      await conn.sendMessage(m.chat, {
        image: { url: result.cover },
        caption
      }, { quoted: m })
    } else {
      await m.reply(caption)
    }

    await conn.sendMessage(m.chat, {
      audio: { url: result.download.mp3 },
      mimetype: 'audio/mpeg',
      fileName: `${(result.title || 'spotify').replace(/[\\/:*?"<>|]/g, '_')}.mp3`
    }, { quoted: m })

  } catch (e) {
    console.error('[SPOTIFY ERROR]', e)
    await m.reply(`❌ Gagal mengunduh lagu.\n\nPesan: ${e.message}`)
  }
}

handler.help = ['spotify']
handler.tags = ['downloader']
handler.command = /^(spotify|spotifydl|spdl)$/i
handler.limit = true

export default handler