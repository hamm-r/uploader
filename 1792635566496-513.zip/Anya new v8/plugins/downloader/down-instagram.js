/**
 * Plugin: instagram.js
 * Name: Instagram Downloader
 * Type: ESM
 * Source: FastVideoSave / VideoDropper API
 * source : https://whatsapp.com/channel/0029VbBSk270AgWIpspK6k3m/1285
 */

import crypto from 'node:crypto'

const AES_KEY = Buffer.from('qwertyuioplkjhgf', 'utf-8')
const BASE_ORIGIN = 'https://fastvideosave.net'
const API_MEDIA = 'https://api.videodropper.app/allinone'
const API_AUDIO = 'https://api.videodropper.app/audio'

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

function encryptUrl(url) {
  const cipher = crypto.createCipheriv('aes-128-ecb', AES_KEY, null)
  cipher.setAutoPadding(true)
  return cipher.update(url, 'utf8', 'hex') + cipher.final('hex')
}

async function requestAPI(endpoint, url) {
  const response = await fetch(endpoint, {
    headers: {
      accept: '*/*',
      origin: BASE_ORIGIN,
      referer: `${BASE_ORIGIN}/`,
      url: encryptUrl(url),
      'user-agent': USER_AGENT
    },
    signal: AbortSignal.timeout(60000)
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(error || `HTTP ${response.status}`)
  }

  return response.json()
}

export async function downloadMedia(url) {
  if (!url || typeof url !== 'string')
    throw new Error('URL Instagram tidak valid')

  const target = url.trim()
  const data = await requestAPI(API_MEDIA, target)

  const videos = (data.video || [])
    .filter(v => v.video)
    .map(v => ({
      url: v.video,
      thumbnail: v.thumbnail || null
    }))

  const images = (data.image || [])
    .map(img => typeof img === 'string' ? img : img.url || img.image)
    .filter(Boolean)

  return {
    sourceUrl: target,
    type: videos.length
      ? images.length ? 'carousel' : 'video'
      : 'image',
    totalVideos: videos.length,
    totalImages: images.length,
    videos,
    images
  }
}

export async function downloadAudio(url) {
  if (!url || typeof url !== 'string')
    throw new Error('URL Instagram tidak valid')

  const target = url.trim()
  const data = await requestAPI(API_AUDIO, target)

  return {
    sourceUrl: target,
    isAudio: Boolean(data.audio),
    media: (data.media || [])
      .filter(m => m.url)
      .map(m => ({
        url: m.url,
        poster: m.poster || null
      }))
  }
}

const handler = async (m, { conn, args, usedPrefix, command }) => {
  const isAudio = /^(igmp3|igaudio)$/i.test(command)
  const input = args.join(' ').trim()

  if (!input) {
    return m.reply(
      `Masukkan URL Instagram!\n\n` +
      `Contoh:\n` +
      `${usedPrefix}ig https://www.instagram.com/reel/xxxxx/\n` +
      `${usedPrefix}igaudio https://www.instagram.com/reel/xxxxx/`
    )
  }

  if (!/^https?:\/\/(www\.)?instagram\.com\//i.test(input)) {
    return m.reply('❌ URL harus berasal dari instagram.com!')
  }

  await conn.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key
    }
  })

  try {
    if (isAudio) {
      const result = await downloadAudio(input)

      if (!result.media.length) {
        throw new Error('Audio atau media tidak ditemukan.')
      }

      for (const item of result.media) {
        await conn.sendMessage(m.chat, {
          audio: { url: item.url },
          mimetype: 'audio/mpeg',
          fileName: 'instagram-audio.mp3'
        }, { quoted: m })
      }
    } else {
      const result = await downloadMedia(input)

      if (!result.videos.length && !result.images.length) {
        throw new Error('Media Instagram tidak ditemukan.')
      }

      for (const item of result.videos) {
        await conn.sendMessage(m.chat, {
          video: { url: item.url },
          caption: `✨ Instagram Downloader\n\n🔗 ${result.sourceUrl}`
        }, { quoted: m })
      }

      for (const item of result.images) {
        await conn.sendMessage(m.chat, {
          image: { url: item },
          caption: `✨ Instagram Downloader\n\n🔗 ${result.sourceUrl}`
        }, { quoted: m })
      }
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: '✅',
        key: m.key
      }
    })
  } catch (error) {
    console.error('[Instagram Downloader]', error)

    await conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    })

    m.reply(`Gagal mengambil media Instagram.\n\n_${error.message || 'Terjadi kesalahan pada API.'}_`)
  }
}

handler.help = ['ig', 'igaudio']
handler.tags = ['downloader']
handler.command = /^(ig|instagram|igaudio|igmp3)$/i
handler.limit = true

export default handler