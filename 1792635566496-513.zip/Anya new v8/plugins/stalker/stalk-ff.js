/**
 * Creator : Kyuu 
 * Ch : https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
 * 
 * note : don't claim this code
 */

import axios from 'axios';

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock;
	const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m });

	if (!text) return doReply(`🔍 *Format:* ${usedPrefix + command} <ID_Akun>\n*Contoh:* ${usedPrefix + command} 123456789`);

	try {
		if (typeof global.react === 'function') await global.react(client, m, 'loading');
		const url = global.API('kyzz', '/api/stalker/freefire', { id: text.trim() }, 'apikey');
		const { data } = await axios.get(url, { timeout: 15000 });
		if (!data?.status || !data?.result) return doReply(`❌ Akun Free Fire dengan ID "${text}" tidak ditemukan.`);

		const r = data.result;
		let cap = `🔥 *FREE FIRE STALKER*\n\n`;
		cap += `• *ID:* ${r.id || text}\n`;
		cap += `• *Nickname:* ${r.nickname || r.name || '-'}\n`;
		if (r.region) cap += `• *Region:* ${r.region}\n`;
		if (r.level) cap += `• *Level:* ${r.level}\n`;
		if (r.likes) cap += `• *Likes:* ${r.likes}\n`;
		if (r.bio) cap += `• *Bio:* ${r.bio}\n`;

		if (r.avatar) {
			await client.sendMessage(m.chat, { image: { url: r.avatar }, caption: cap.trim() }, { quoted: m });
		} else {
			await doReply(cap.trim());
		}
		if (typeof global.react === 'function') await global.react(client, m, 'success');
	} catch (e) {
		console.error('[STALK-FF]', e.response?.data || e);
		if (typeof global.react === 'function') await global.react(client, m, 'error');
		doReply(`❌ Gagal stalk Free Fire: ${e.response?.data?.error || e.message}`);
	}
};

handler.help = ['stalkff <id>'];
handler.tags = ['stalker'];
handler.command = /^(stalkff|ffstalk)$/i;
handler.limit = true;
handler.register = true;
export default handler;
