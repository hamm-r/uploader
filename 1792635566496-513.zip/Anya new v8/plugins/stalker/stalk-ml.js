/**
 * Creator : Kyuu 
 * Ch : https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
 * 
 * note : don't claim this code
 */

import axios from 'axios';

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock;
	const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m });

	const parts = text ? text.trim().split(/[s|]+/) : [];
	if (parts.length < 2) return doReply(`🔍 *Format:* ${usedPrefix + command} <User_ID> <Zone_ID>\n*Contoh:* ${usedPrefix + command} 1264042367 15139`);

	try {
		if (typeof global.react === 'function') await global.react(client, m, 'loading');
		const url = global.API('kyzz', '/api/stalker/ml', { id: parts[0], zone_id: parts[1] }, 'apikey');
		const { data } = await axios.get(url, { timeout: 15000 });
		if (!data?.status || !data?.result) return doReply(`❌ Akun ML (${parts[0]} - ${parts[1]}) tidak ditemukan.`);

		const r = data.result;
		let cap = `🎮 *MOBILE LEGENDS STALKER*\n\n`;
		cap += `• *Nickname:* ${r.username || r.display_name || '-'}\n`;
		cap += `• *User ID:* ${r.user_id || parts[0]}\n`;
		cap += `• *Zone ID:* ${r.zone_id || parts[1]}\n`;
		cap += `• *Region:* ${r.region || '-'}\n`;
		cap += `• *Game:* ${r.game || 'Mobile Legends'}\n`;

		if (r.avatar) {
			await client.sendMessage(m.chat, { image: { url: r.avatar }, caption: cap.trim() }, { quoted: m });
		} else {
			await doReply(cap.trim());
		}
		if (typeof global.react === 'function') await global.react(client, m, 'success');
	} catch (e) {
		console.error('[STALK-ML]', e.response?.data || e);
		if (typeof global.react === 'function') await global.react(client, m, 'error');
		doReply(`❌ Gagal stalk ML: ${e.response?.data?.error || e.message}`);
	}
};

handler.help = ['stalkml <id> <zone_id>'];
handler.tags = ['stalker'];
handler.command = /^(stalkml|mlstalk)$/i;
handler.limit = true;
handler.register = true;
export default handler;
