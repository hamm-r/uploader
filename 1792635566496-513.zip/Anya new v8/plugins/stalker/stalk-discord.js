/**
 * Creator : Kyuu 
 * Ch : https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
 * 
 * note : don't claim this code
 */

import axios from 'axios';

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock;
	const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m });

	if (!text) return doReply(`🔍 *Format:* ${usedPrefix + command} <User_ID>\n*Contoh:* ${usedPrefix + command} 1234567890123456789`);

	try {
		if (typeof global.react === 'function') await global.react(client, m, 'loading');
		const url = global.API('kyzz', '/api/stalker/discord', { id: text.trim() }, 'apikey');
		const { data } = await axios.get(url, { timeout: 15000 });
		if (!data?.status || !data?.result) return doReply(`❌ User Discord dengan ID "${text}" tidak ditemukan.`);

		const r = data.result;
		let cap = `💬 *DISCORD USER STALKER*\n\n`;
		cap += `• *ID:* ${r.id || text}\n`;
		cap += `• *Username:* ${r.username || '-'}\n`;
		cap += `• *Dibuat:* ${r.created || '-'}\n`;
		cap += `• *Badges:* ${r.badges || '-'}\n`;

		if (r.avatar) {
			await client.sendMessage(m.chat, { image: { url: r.avatar }, caption: cap.trim() }, { quoted: m });
		} else {
			await doReply(cap.trim());
		}
		if (typeof global.react === 'function') await global.react(client, m, 'success');
	} catch (e) {
		console.error('[STALK-DISCORD]', e.response?.data || e);
		if (typeof global.react === 'function') await global.react(client, m, 'error');
		doReply(`❌ Gagal stalk Discord: ${e.response?.data?.error || e.message}`);
	}
};

handler.help = ['stalkdiscord <id>'];
handler.tags = ['stalker'];
handler.command = /^(stalkdiscord|discordstalk)$/i;
handler.limit = true;
handler.register = true;
export default handler;
