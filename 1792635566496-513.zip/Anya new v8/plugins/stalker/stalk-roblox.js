/**
 * Creator : Kyuu 
 * Ch : https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
 * 
 * note : don't claim this code
 */

import axios from 'axios';

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock;
	const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m });

	if (!text) return doReply(`🔍 *Format:* ${usedPrefix + command} <username>\n*Contoh:* ${usedPrefix + command} builderman`);

	try {
		if (typeof global.react === 'function') await global.react(client, m, 'loading');
		const url = global.API('kyzz', '/api/stalker/roblox', { username: text.trim() }, 'apikey');
		const { data } = await axios.get(url, { timeout: 15000 });
		if (!data?.status || !data?.result) return doReply(`❌ User Roblox "${text}" tidak ditemukan.`);

		const b = data.result.basic || data.result;
		let cap = `🧱 *ROBLOX STALKER*\n\n`;
		cap += `• *User ID:* ${data.result.userId || '-'}\n`;
		cap += `• *Username:* ${data.username || text}\n`;
		cap += `• *Deskripsi:* ${b.description || '-'}\n`;
		cap += `• *Dibuat:* ${b.created || '-'}\n`;
		cap += `• *Banned:* ${b.isBanned ? 'Ya ❌' : 'Tidak ✅'}\n`;
		cap += `• *Verified Badge:* ${b.hasVerifiedBadge ? 'Ya ✔️' : 'Tidak'}\n`;

		const img = data.result.avatar || b.avatar;
		if (img) {
			await client.sendMessage(m.chat, { image: { url: img }, caption: cap.trim() }, { quoted: m });
		} else {
			await doReply(cap.trim());
		}
		if (typeof global.react === 'function') await global.react(client, m, 'success');
	} catch (e) {
		console.error('[STALK-ROBLOX]', e.response?.data || e);
		if (typeof global.react === 'function') await global.react(client, m, 'error');
		doReply(`❌ Gagal stalk Roblox: ${e.response?.data?.error || e.message}`);
	}
};

handler.help = ['stalkroblox <username>'];
handler.tags = ['stalker'];
handler.command = /^(stalkroblox|robloxstalk)$/i;
handler.limit = true;
handler.register = true;
export default handler;
