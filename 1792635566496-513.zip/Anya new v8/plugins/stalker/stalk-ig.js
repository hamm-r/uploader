/*
 * Christy AI WhatsApp Bot
 * Bot       : Christy MD
 * Developer : Riki
 * Library   : @itsliaaa/baileys
 * Module    : ESM Plugin
 * Channel   : https://whatsapp.com/channel/0029VbClbR4AInPdUfdBQ53I
 */
/**
 * ig stalk
 * Sources: https://whatsapp.com/channel/0029VbCJ0B0K0IBlYlYJ0W3c (RennZSync)
 * Type Plugin ESM
 * RennZSync
 * By Snøwi
 * ubah wm atau apus wm yatim
 *
 * Lookup: HTML publik Insta Stories Viewer (dapat berupa cache).
 * AIRich: addCompact + divider + See results, sesuai susunan contoh.
 */

import axios from 'axios';
import { load } from 'cheerio';
import { AIRich } from '../../lib/ui/MessageBuilderv2.js';

const SOURCE = 'https://insta-stories-viewer.com';
const FALLBACK_PHOTO = 'https://files.catbox.moe/bpmmcz.jpeg';
const CHANNEL = 'https://whatsapp.com/channel/0029VbCJ0B0K0IBlYlYJ0W3c';

async function lookupInstagram(username) {
    const sourceUrl = `${SOURCE}/${encodeURIComponent(username)}/`;
    const { data: html } = await axios.get(sourceUrl, {
        timeout: 20000,
        responseType: 'text',
        maxRedirects: 5,
        maxContentLength: 2 * 1024 * 1024,
        headers: {
            Accept: 'text/html',
            'Accept-Language': 'en-US,en;q=0.9'
        }
    });

    if (typeof html !== 'string') {
        throw new Error('Respons sumber bukan HTML.');
    }

    const $ = load(html);
    const returnedUsername = ($('.profile__tabs').first()
        .attr('data-username') || '').trim().toLowerCase();

    if (returnedUsername !== username) {
        throw new Error('Profil belum tersedia atau halaman meminta verifikasi browser.');
    }

    const readText = (selector, maxLength = 1500) => $(selector).first()
        .text().replace(/\s+/g, ' ').trim().slice(0, maxLength);

    let profilePic = null;
    const avatarSrc = $('.profile__avatar-pic').first().attr('src')?.trim();
    if (avatarSrc) {
        try {
            const url = new URL(avatarSrc, sourceUrl);
            if (url.protocol === 'https:' && !url.username && !url.password) {
                profilePic = url.href;
            }
        } catch {
            // Tetap kirim data teks di dalam AIRich bila URL gambar tidak valid.
        }
    }

    return {
        username: returnedUsername,
        profileUrl: `https://www.instagram.com/${returnedUsername}/`,
        profilePic,
        biography: readText('.profile__description'),
        posts: readText('.profile__stats-posts', 80),
        followers: readText('.profile__stats-followers', 80),
        following: readText('.profile__stats-follows', 80)
    };
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text?.trim()) {
        throw `Masukkan username Instagram target!\n\n*Contoh:* ${usedPrefix + command} rennz_dev`;
    }

    const username = text.trim().replace(/^@/, '').toLowerCase();
    if (
        !/^[a-z0-9._]{1,30}$/.test(username) ||
        username.startsWith('.') ||
        username.endsWith('.') ||
        username.includes('..')
    ) {
        throw 'Username tidak valid. Kirim username saja, bukan URL atau teks tambahan.';
    }

    let profile;
    try {
        profile = await lookupInstagram(username);
    } catch (err) {
        console.error(`[IG Lookup Error] ${username}:`, err?.message || err);
        throw 'Gagal mengambil profil dari Insta Stories Viewer. Data mungkin belum tersedia, sumber sedang bermasalah, atau membutuhkan verifikasi browser. Coba lagi nanti.';
    }

    const rich = new AIRich(conn);

    if (typeof rich.addCompact !== 'function') {
        throw 'Library AIRich belum diperbarui. Ganti lib/ui/MessageBuilder.js dengan versi yang mendukung addCompact(), lalu restart bot.';
    }

    rich.addCompact({
        title: 'Chrisy ig stalk',
        subtitle: '',
        secondary_subtitle: '',
        image: profile.profilePic || FALLBACK_PHOTO,
        entity_id: profile.username,
        entity_url: CHANNEL,
        entity_type: 'WEBSITE',
        action_type: 'OPEN_URL'
        // Jangan menambahkan verified tanpa data yang terkonfirmasi.
    });

    rich.addSection({
        view_model: {
            primitives: [
                { type: 'HORIZONTAL_LINE', __typename: 'GenAIDividerPrimitive' }
            ],
            __typename: 'GenAIVStackLayoutViewModel'
        }
    });

    rich.addSection({
        view_model: {
            primitives: [
                { __typename: 'GenAISpacerPrimitive' },
                {
                    text: '# {{social_entity_1}}See results{{/social_entity_1}}',
                    inline_entities: [
                        {
                            key: 'social_entity_1',
                            metadata: {
                                __typename: 'GenAISocialEntityItem',
                                entity_id: profile.username,
                                entity_name: profile.username,
                                ...(profile.profilePic
                                    ? { entity_picture_url: profile.profilePic }
                                    : {}),
                                entity_url: profile.profileUrl,
                                entity_type: 'IG_PROFILE'
                                // Nama lengkap dan verified tidak tersedia di HTML awal.
                            }
                        }
                    ],
                    __typename: 'GenAIMarkdownTextUXPrimitive'
                },
                { __typename: 'GenAISpacerPrimitive' }
            ],
            __typename: 'GenAIActionRowLayoutViewModel'
        }
    });

    rich.setFooter('Insta Stories Viewer • data bisa terlambat');

    try {
        await rich.send(m.chat, { quoted: m });
    } catch (err) {
        console.error(`[IG AIRich Error] ${username}:`, err?.stack || err);
        // Tidak mengirim ulang otomatis: send() mungkin telah relay sebelum edit gagal.
        throw 'Data profil berhasil diambil, tetapi pengiriman atau edit AIRich gagal. Periksa log server. Pesan mungkin sudah terkirim sebagian.';
    }
};

handler.help = ['instalookup <username>', 'igstalk <username>'];
handler.tags = ['tools', 'stalker'];
handler.command = /^(instalookup|igstalk|instalookupai)$/i;

export default handler;