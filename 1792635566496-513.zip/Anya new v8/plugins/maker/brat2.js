/**
 * bratvid/Brat2.js
 * Creator: Shan (Modified to use API)
 * Saluran: https://whatsapp.com/channel/0029VbB4Kw8EFeXfeExaXc3Q/498
 *
 * ESM Plugin 
 */

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply('Contoh:\n.brat2 Halo dunia 🤩');
  }

  try {
    await m.react('⏳');
    
    // Encode teks agar aman dilempar ke dalam URL API
    const apiUrl = `https://apiii-xrina.vercel.app/maker/bratvid2?text=${encodeURIComponent(text.trim())}`;

    // Kirim langsung video dari URL API
    await conn.sendMessage(
      m.chat, 
      { 
        video: { url: apiUrl }, 
        mimetype: 'video/mp4', 
        fileName: 'brat.mp4', 
        gifPlayback: true // Membuatnya berputar seperti GIF (opsional)
      }, 
      { quoted: m }
    );

    await m.react('✅');
  } catch (e) {
    console.error('[BRAT2 API]', e);
    await m.react('❌');
    await m.reply(`❌ Gagal membuat brat!\n\n${e.message || e}`);
  }
};

handler.help = ['brat2 <teks>'];
handler.tags = ['maker'];
handler.command = ['brat2'];
handler.limit = true;

export default handler;