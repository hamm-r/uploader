/**
 * Spotify Search
 * Type: Plugin ESM
 */

import {
  spotify,
  spotifyUrl,
  parseTrack,
  parseSearch,
  formatTrack,
  formatSearch
} from '../../lib/scrape/Spotify.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎧 *SPOTIFY SEARCH*\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} NIKI lowkey\n` +
      `${usedPrefix + command} https://open.spotify.com/track/xxxx`
    )
  }

  try {
    await m.react?.('🕒')

    const parsed = spotifyUrl(text)

    if (parsed?.type === 'track') {
      const raw = await spotify.track(parsed.id)
      const data = parseTrack(raw)

      if (!data) throw new Error('Track tidak ditemukan')

      const caption = formatTrack(data)

      if (data.album.image) {
        await conn.sendMessage(m.chat, {
          image: { url: data.album.image },
          caption
        }, { quoted: m })
      } else {
        await m.reply(caption)
      }

      await m.react?.('✅')
      return
    }

    const raw = await spotify.search(text)
    const list = parseSearch(raw)

    if (!list.length) throw new Error('Lagu tidak ditemukan')

    const caption = formatSearch(list, text)
    const thumb = list[0]?.album?.image

    if (thumb) {
      await conn.sendMessage(m.chat, {
        image: { url: thumb },
        caption
      }, { quoted: m })
    } else {
      await m.reply(caption)
    }

    await m.react?.('✅')
  } catch (e) {
    await m.react?.('❌')
    await m.reply(`Gagal mengambil data Spotify.\n\n${e.message}`)
  }
}

handler.help = ['spotify <query/link>', 'sp <query/link>']
handler.tags = ['internet']
handler.command = /^(spotify|sp)$/i
handler.limit = true

export default handler