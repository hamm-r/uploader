/**
 ╔══════════════════════
     ⧉  [bingimage] — [search]
╚══════════════════════

  ✺ Type     : Plugin ESM
  ✺ Source   : https://whatsapp.com/channel/0029VbAXhS26WaKugBLx4E05
  ✺ Creator  : SXZnightmare
  ✺ Scrape      : 
  [ ytta ]
  ✺ Scrape Maker : [ Z7 ]
  ✺ Req    : Z7 [ Theresa ex Apocalypse ]
*/

import { getBingImages } from '../../lib/scrape/bingimage.js';

const TTL_MS = 3 * 60 * 1000;
const CACHE = new Map();
const Bookmarks = new Map();

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        if (!text) return m.reply(`*Contoh:* ${usedPrefix + command} anime girl`);
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        const query = text.trim();
        const limit = 6;
        const cacheKey = `bing:${query}`;
        const bookmarkKey = `${m.sender}:${query}`;
        const now = Date.now();
        let results;
        const cached = CACHE.get(cacheKey);
        if (cached && now - cached.ts < TTL_MS) {
            results = cached.data;
        } else {
            results = await getBingImages(query, 30);
            if (!results.length) return m.reply(`🍂 *Gambar tidak ditemukan.*`);
            CACHE.set(cacheKey, { ts: now, data: results });
        }
        const bookmarkIndex = Bookmarks.get(bookmarkKey) || 0;
        const startIndex = bookmarkIndex * limit;
        const endIndex = startIndex + limit;
        const images = results.slice(startIndex, endIndex);
        if (images.length === 0) {
            Bookmarks.set(bookmarkKey, 0);
            return m.reply("🍂 *Tidak ada gambar lagi untuk query ini.*");
        }
        for (const img of images) {
            await conn.sendMessage(
                m.chat,
                {
                    image: { url: img.preview_url || img.original_url }
                },
                { quoted: m }
            );
        }
        Bookmarks.set(bookmarkKey, bookmarkIndex + 1);
    } catch {
        await m.reply(`🍂 *Gagal mengambil gambar.*`);
    } finally {
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
    }
};

handler.help = ["bingimage"];
handler.tags = ["search"];
handler.command = /^(bingimage)$/i;
handler.limit = true;
handler.register = false; // true kan jika ada fitur register atau daftar di bot mu.

export default handler;