/*
 * ==============================================
 * NEKOPOI SCRAPER — ESM PLUGIN
 * ==============================================
 * Command:
 * .nekopoi <query>
 * .nekopoi latest
 * .nekopoi detail <url>
 * .nekopoi genre <genre>
 * .nekopoi category <category>
 * .nekopoi schedule
 *
 * Dependency:
 * npm install axios cheerio
 * ==============================================
 */

import {
    search,
    getLatest,
    getCategory,
    getByGenre,
    getSchedule,
    getDetail,
    formatResults
} from '../../lib/scrape/nekopoi.js';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    text = text?.trim() || ''

    if (!text) {
        return m.reply(
`╭─「 NEKOPOI 」─
│
│ ${usedPrefix + command} <query>
│
│ Contoh:
│ ${usedPrefix + command} latest
│ ${usedPrefix + command} search
│ ${usedPrefix + command} mahiru
│ ${usedPrefix + command} genre action
│ ${usedPrefix + command} category hentai
│ ${usedPrefix + command} schedule
│ ${usedPrefix + command} detail <url>
│
╰────────────────`
        )
    }

    await m.reply('⏳ Sebentar, lagi nyari datanya...')

    try {
        const args = text.split(/\s+/)
        const action = args[0].toLowerCase()

        let result

        // ====================================
        // LATEST
        // ====================================

        if (action === 'latest') {
            const page =
                parseInt(args[1]) || 1

            result =
                await getLatest(page)

            return m.reply(
                formatResults(
                    result,
                    `Latest — Page ${page}`
                )
            )
        }

        // ====================================
        // SEARCH
        // ====================================

        if (action === 'search') {
            const query =
                args.slice(1).join(' ')

            if (!query)
                return m.reply(
                    `Contoh: ${usedPrefix + command} search mahiru`
                )

            result =
                await search(query)

            return m.reply(
                formatResults(
                    result,
                    `Search: ${query}`
                )
            )
        }

        // ====================================
        // GENRE
        // ====================================

        if (action === 'genre') {
            const genre = args[1]

            if (!genre)
                return m.reply(
                    `Contoh: ${usedPrefix + command} genre action`
                )

            result =
                await getByGenre(genre)

            return m.reply(
                formatResults(
                    result,
                    `Genre: ${genre}`
                )
            )
        }

        // ====================================
        // CATEGORY
        // ====================================

        if (action === 'category') {
            const category = args[1]

            if (!category)
                return m.reply(
                    `Contoh: ${usedPrefix + command} category hentai`
                )

            result =
                await getCategory(category)

            return m.reply(
                formatResults(
                    result,
                    `Category: ${category}`
                )
            )
        }

        // ====================================
        // SCHEDULE
        // ====================================

        if (action === 'schedule') {
            result =
                await getSchedule()

            if (!result.length)
                return m.reply(
                    '❌ Jadwal tidak ditemukan.'
                )

            let msg =
                '╭─「 SCHEDULE 」\n'

            result
                .slice(0, 15)
                .forEach((item, i) => {
                    msg += `│\n`
                    msg += `│ ${i + 1}. *${item.title}*\n`

                    if (item.episode)
                        msg += `│ 🎬 ${item.episode}\n`

                    if (item.releaseDate)
                        msg += `│ 📅 ${item.releaseDate}\n`

                    if (item.producer)
                        msg += `│ 🏷️ ${item.producer}\n`

                    if (item.subIndo)
                        msg += `│ 🇮🇩 ${item.subIndo}\n`
                })

            msg += `│\n╰─ Total: ${result.length}`

            return m.reply(msg)
        }

        // ====================================
        // DETAIL
        // ====================================

        if (action === 'detail') {
            const url =
                args.slice(1).join(' ')

            if (!url)
                return m.reply(
                    `Contoh: ${usedPrefix + command} detail https://nekopoi.care/...`
                )

            result =
                await getDetail(url)

            let msg =
                `╭─「 DETAIL 」\n│\n`

            msg += `│ 🎬 *${result.title}*\n`
            msg += `│\n`

            if (result.type === 'series') {
                if (result.synopsis)
                    msg += `│ 📖 ${result.synopsis}\n│\n`

                if (
                    result.episodes?.length
                ) {
                    msg += `│ 📺 Episodes: ${result.episodes.length}\n`

                    result.episodes
                        .slice(0, 10)
                        .forEach((ep, i) => {
                            msg += `│ ${i + 1}. ${ep.title}\n`
                            msg += `│ 🔗 ${ep.url}\n`
                        })
                }
            } else {
                if (
                    Object.keys(result.metadata || {})
                        .length
                ) {
                    for (const [
                        key,
                        value
                    ] of Object.entries(
                        result.metadata
                    )) {
                        msg += `│ ${key}: ${value}\n`
                    }

                    msg += `│\n`
                }

                if (result.m3u8s?.length) {
                    msg += `│ 🎥 Stream:\n`

                    result.m3u8s.forEach(
                        (url, i) => {
                            msg += `│ ${i + 1}. ${url}\n`
                        }
                    )

                    msg += `│\n`
                }

                if (result.downloads?.length) {
                    msg += `│ 📥 Download:\n`

                    result.downloads.forEach(
                        item => {
                            msg += `│ • ${item.name}\n`

                            item.links.forEach(
                                link => {
                                    msg += `│   ${link.host}: ${link.url}\n`
                                }
                            )
                        }
                    )
                }
            }

            msg += `│\n╰─ ${result.url}`

            return m.reply(msg)
        }

        // ====================================
        // DEFAULT = SEARCH
        // ====================================

        result =
            await search(text)

        return m.reply(
            formatResults(
                result,
                `Search: ${text}`
            )
        )

    } catch (error) {
        console.error(
            '[NEKOPOI ERROR]',
            error
        )

        return m.reply(
            `❌ Terjadi error:\n\n${error.message}`
        )
    }
}

handler.help = [
    'nekopoi <query>',
    'nekopoi latest',
    'nekopoi search <query>',
    'nekopoi genre <genre>',
    'nekopoi category <category>',
    'nekopoi schedule',
    'nekopoi detail <url>'
]

handler.tags = ['search']
handler.command = /^nekopoi$/i

handler.limit = true

export default handler