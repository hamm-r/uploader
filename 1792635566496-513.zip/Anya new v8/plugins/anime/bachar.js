/**
 * Creator : Kyuu 
 * Ch : https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
 * 
 * note : don't claim this code
 */

import axios from "axios";

const BASE = "https://api.dotgg.gg";

export class BlueArchive {
    findUrl(input, urls) {
        const clean = input.toLowerCase().replace(/\s+/g, "_");
        if (urls.includes(clean)) return clean;

        const words = clean.split("_");
        const matches = urls.filter((url) =>
            words.every((word) => url.toLowerCase().includes(word))
        );

        return matches.length > 0 ? matches[0] : null;
    }

    async list() {
        const { data } = await axios.get(`${BASE}/bluearchive/characters`);

        return data.map((item) => ({
            ...item,
            imgSmall: item.imgSmall ?
                "https://images.dotgg.gg/bluearchive/characters/" + item.imgSmall :
                null,
            img: item.img ?
                "https://images.dotgg.gg/bluearchive/characters/" + item.img :
                null,
        }));
    }

    async char(name) {
        const listc = await this.list();
        const urls = listc.map((c) => c.url);
        const foundUrl = this.findUrl(name, urls);

        if (!foundUrl) {
            const suggestions = urls
                .filter((u) => u.includes(name.toLowerCase().split(" ")[0]))
                .slice(0, 5);

            throw new Error(
                `Character "${name}" tidak ditemukan.\n\n> Mungkin maksud: ${
                    suggestions.join(", ") || "tidak ada"
                }`
            );
        }

        const { data } = await axios.get(
            `${BASE}/bluearchive/characters/${foundUrl}`
        );

        return {
            ...data,
            imgSmall: data.imgSmall ?
                "https://images.dotgg.gg/bluearchive/characters/" + data.imgSmall :
                null,
            img: data.img ?
                "https://images.dotgg.gg/bluearchive/characters/" + data.img :
                null,
        };
    }
}

export const blueArchive = new BlueArchive();

const handler = async (m, { conn, sock, text, usedPrefix, command, reply, Func }) => {
    const client = conn || sock;
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : (txt) => client.sendMessage(m.chat, { text: txt }, { quoted: m });

    try {
        if (!text) {
            return doReply(`🎮 *Cara Penggunaan:*\n> ${usedPrefix + command} <nama_character>\n\n*Contoh:*\n> ${usedPrefix + command} shiroko`);
        }

        if (typeof global.react === "function") {
            await global.react(client, m, "loading");
        } else if (client.sendMessage) {
            await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => {});
        }

        const char = await blueArchive.char(text);

        let caption = `🎮 *BLUE ARCHIVE CHARACTER*\n\n`;
        caption += `🏷️ *Name:* ${char.name ? char.name.toUpperCase() : "-"}\n\n`;

        if (char.bio) {
            const bioClean = char.bio.replace(/<[^>]*>?/gm, "").trim();
            caption += `📝 *Bio:*\n> ${bioClean.substring(0, 200)}${bioClean.length > 200 ? "..." : ""}\n\n`;
        }

        caption += `╭┈┈⬡「 📋 *PROFILE* 」\n`;
        if (char.profile?.familyName) caption += `┃ 👤 Family: *${char.profile.familyName}*\n`;
        if (char.profile?.age) caption += `┃ 🎂 Age: *${char.profile.age}*\n`;
        if (char.profile?.height) caption += `┃ 📏 Height: *${char.profile.height}*\n`;
        if (char.profile?.school) caption += `┃ 🏫 School: *${char.profile.school}*\n`;
        if (char.profile?.club) caption += `┃ 🎯 Club: *${char.profile.club}*\n`;
        if (char.profile?.hobby) caption += `┃ ⭐ Hobby: *${char.profile.hobby}*\n`;
        if (char.profile?.CV) caption += `┃ 🎤 CV: *${char.profile.CV}*\n`;
        caption += `╰┈┈┈┈┈┈┈┈⬡\n\n`;

        caption += `╭┈┈⬡「 ⚔️ *BATTLE INFO* 」\n`;
        if (char.type) caption += `┃ 🏷️ Type: *${char.type}*\n`;
        if (char.role) caption += `┃ 🎭 Role: *${char.role}*\n`;
        if (char.position) caption += `┃ 📍 Position: *${char.position}*\n`;
        if (char.profile?.weaponType) caption += `┃ 🔫 Weapon: *${char.profile.weaponType}*\n`;
        if (char.profile?.weaponName) caption += `┃ ⚔️ Weapon Name: *${char.profile.weaponName}*\n`;
        caption += `╰┈┈┈┈┈┈┈┈⬡\n\n`;

        if (char.skills?.length) {
            caption += `╭┈┈⬡「 ✨ *SKILLS* 」\n`;
            for (const skill of char.skills.slice(0, 4)) {
                caption += `┃ 🔹 *${skill.name}* (${skill.type || "-"})\n`;
            }
            caption += `╰┈┈┈┈┈┈┈┈⬡\n`;
        }

        let imgBuffer = null;
        if (char.img || char.imgSmall) {
            try {
                const imgRes = await axios.get(char.img || char.imgSmall, {
                    responseType: "arraybuffer",
                    timeout: 10000
                });
                imgBuffer = imgRes.data;
            } catch (e) {
                imgBuffer = null;
            }
        }

        const newsletterName = global.namech || global.namaBot || "Hirara AI";
        const newsletterJid = global.idch || "120363424661023086@newsletter";

        if (imgBuffer) {
            await client.sendMessage(
                m.chat,
                {
                    image: imgBuffer,
                    caption: caption.trim(),
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: newsletterJid,
                            newsletterName: newsletterName,
                            serverMessageId: 100
                        }
                    }
                },
                { quoted: m }
            );
        } else {
            await doReply(caption.trim());
        }

        if (typeof global.react === "function") {
            await global.react(client, m, "success");
        } else if (client.sendMessage) {
            await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => {});
        }

    } catch (e) {
        console.error("[BACHAR ERROR]", e);
        if (typeof global.react === "function") {
            await global.react(client, m, "error");
        } else if (client.sendMessage) {
            await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
        }

        return doReply(`❌ ${e?.message || e}`);
    }
};

handler.help = ["bachar <nama>"];
handler.tags = ["anime"];
handler.command = ["bachar", "ba", "bluearchive"];
handler.limit = true;
handler.register = true;

export default handler;
