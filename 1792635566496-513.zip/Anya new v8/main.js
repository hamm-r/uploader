process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

// ============================================================
// 1. IMPORTS
// ============================================================
// Node.js Built-ins
import fs from 'fs';
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { platform } from 'process';
import { createRequire } from 'module';

// Third-party Libraries
import chalk from 'chalk';
import pino from 'pino';
import syntaxerror from 'syntax-error';
import sharp from 'sharp';

// Baileys & WhatsApp Auth
import {
  useMultiFileAuthState,
  Browsers,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  DisconnectReason
} from '@rexxhayanasi/elaina-baileys';

// Local Modules
import { SqlJsDatabase } from './lib/database.js';
import { makeWASocket, protoType, serialize } from './lib/simple.js';
import { restoreSubBots } from './lib/jadibot.js';

// ============================================================
// 2. SETUP & OPTIMIZATIONS
// ============================================================
try {
  sharp.cache(false);
  sharp.concurrency(1);
  sharp.simd(true);
} catch (_) {}

// ============================================================
// 3. GLOBAL PATHS & VARIABLES
// ============================================================
global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
  return rmPrefix
    ? (/file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL)
    : pathToFileURL(pathURL).toString();
};

global.__dirname = function dirname(pathURL) {
  return path.dirname(global.__filename(pathURL, true));
};

global.__require = function require(dir = import.meta.url) {
  return createRequire(dir);
};

const __dirname = global.__dirname(import.meta.url);

global.opts = global.opts || {};
global.prefix = global.prefix || /^[./#!]/;
global.stopped = false;

// ============================================================
// 4. CONFIGURATION LOAD
// ============================================================
try {
  if (fs.existsSync('./config.js')) {
    await import('./config.js');
    global.opts.self = Boolean(global.self);
    console.log(chalk.green('[CONFIG] Config loaded'));
  } else {
    console.log(chalk.yellow('[CONFIG] config.js tidak ditemukan! Membuat default...'));
    fs.writeFileSync('./config.js', `
global.owner = ['628xxx'];
global.anticall = true;
`);
  }
} catch (e) {
  console.log(chalk.red('[CONFIG] Error loading config:'), e.message);
}

// ============================================================
// 5. BAILEYS PROTOTYPE SETUP
// ============================================================
protoType();
serialize();

// ============================================================
// 6. DATABASE INITIALIZATION & REPAIR
// ============================================================
const databasePath = path.resolve('./database.sqlite');
global.db = new SqlJsDatabase(databasePath);

try {
  console.log(chalk.cyan('[DATABASE] Menginisialisasi database...'));
  await global.db.init();

  if (!global.db.data || typeof global.db.data !== 'object') {
    throw new Error('Data database tidak tersedia setelah init().');
  }

  if (typeof global.db.repair === 'function') {
    console.log(chalk.cyan('[DATABASE] Menjalankan pemeriksaan integritas...'));
    const repaired = await global.db.repair();
    if (repaired === false) {
      console.error(chalk.yellow('[DATABASE] Repair belum berhasil. Database dan backup dipertahankan.'));
    }
  } else {
    console.warn(chalk.yellow('[DATABASE] Method repair() belum tersedia di lib/database.js.'));
  }

  global.loadDatabase = async function loadDatabase() {
    return global.db.data;
  };

  const usersCount = Object.keys(global.db.data.users || {}).length;
  const chatsCount = Object.keys(global.db.data.chats || {}).length;
  console.log(chalk.green(`[DATABASE] Siap | Users: ${usersCount} | Chats: ${chatsCount}`));
} catch (error) {
  console.error(chalk.red('[DATABASE] Gagal inisialisasi:'), error);
  console.error(chalk.red('[DATABASE] Bot dihentikan untuk mencegah data kosong menimpa database lama.'));
  process.exit(1);
}

// Data Repair Logic
console.log(chalk.cyan('[DATABASE] Memeriksa data user...'));
let repairedFields = 0;

global.db.data.users = global.db.data.users || {};
global.db.data.chats = global.db.data.chats || {};
global.db.data.settings = global.db.data.settings || {};

for (const id of Object.keys(global.db.data.users)) {
  const user = global.db.data.users[id];
  if (!user || typeof user !== 'object' || Array.isArray(user)) {
    console.warn(`[DATABASE] Data user tidak valid dilewati: ${id}`);
    continue;
  }

  const defaultKeys = {
    exp: 0, level: 0, money: 0, limit: 50, premiumTime: 0, lastclaim: 0, lastWarn: 0
  };

  for (const [key, value] of Object.entries(defaultKeys)) {
    if (!Number.isFinite(user[key])) {
      user[key] = value;
      repairedFields++;
    }
  }
}
console.log(chalk.green(`[DATABASE] Pemeriksaan selesai: ${repairedFields} field diperbaiki.`));

// ============================================================
// 7. SESSION & AUTHENTICATION
// ============================================================
const sessionDir = path.resolve('./sessions');
const credsFile = path.join(sessionDir, 'creds.json');

try {
  if (fs.existsSync(credsFile)) {
    const creds = JSON.parse(fs.readFileSync(credsFile, 'utf8'));
    if (!creds || typeof creds !== 'object') {
      console.error(chalk.red('[SESSION] Format kredensial tidak valid. File dipertahankan.'));
    } else if (!creds.registered) {
      console.warn(chalk.yellow('[SESSION] Sesi belum terdaftar. Folder sessions tidak dihapus.'));
    }
  }
} catch (error) {
  console.error('[SESSION] Pemeriksaan sesi gagal:', error.message);
}

const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
const { version } = await fetchLatestBaileysVersion();

const connectionOptions = {
  auth: {
    creds: state.creds,
    keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
  },
  version,
  logger: pino({ level: 'silent' }),
  browser: Browsers.ubuntu('Chrome'),
  generateHighQualityLinkPreview: false,
  syncFullHistory: false,
  shouldSyncHistoryMessage: () => false,
  markOnlineOnConnect: false,
  connectTimeoutMs: 60000,
  keepAliveIntervalMs: 30000,
  retryRequestDelayMs: 250,
  maxMsgRetryCount: 5,
  printQRInTerminal: false
};

global.conn = makeWASocket(connectionOptions);

// ============================================================
// 8. PAIRING CODE LOGIC
// ============================================================
global.pairingRequested = false;
global.pairingInputShown = false;

global.requestPairing = async function () {
  if (global.pairingRequested || global.conn?.authState?.creds?.registered) return;
  if (global.pairingInputShown) return;

  global.pairingInputShown = true;
  const readline = await import('node:readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ask = question => new Promise(resolve => rl.question(question, resolve));

  try {
    let phoneNumber = global.nomorbot || '';

    if (!phoneNumber) {
      console.log(chalk.cyan('\n╭────────「 ANYA MD 」────────╮'));
      console.log(chalk.cyan('│  🔐 MANUAL PAIRING MODE'));
      console.log(chalk.cyan('│  Nomor tidak diambil dari config.js'));
      console.log(chalk.cyan('╰─────────────────────────────╯'));
      phoneNumber = String(await ask(chalk.yellow('📱 Masukkan nomor WhatsApp: ')));
    }

    phoneNumber = String(phoneNumber).replace(/\D/g, '').replace(/^0+/, '');

    if (!phoneNumber || phoneNumber.length < 8) {
      console.log(chalk.red('❌ Nomor tidak valid. Jalankan ulang bot.'));
      rl.close();
      global.pairingInputShown = false;
      return;
    }

    global.pairingRequested = true;
    console.log(chalk.blue(`\n⏳ Generating pairing code untuk +${phoneNumber}...`));

    let code = await global.conn.requestPairingCode(phoneNumber);
    code = code?.match(/.{1,4}/g)?.join('-') || code;

    console.log(chalk.black(chalk.bgGreen(' PAIRING CODE ')) + ' ' + chalk.white(code));
    console.log(chalk.green('\n✅ Masukkan code di WhatsApp → Perangkat tertaut → Tautkan dengan nomor telepon.\n'));
    rl.close();
  } catch (error) {
    global.pairingRequested = false;
    global.pairingInputShown = false;
    try { rl.close(); } catch {}
    console.log(chalk.red('❌ Error pairing:'), error.message);
  }
};

// ============================================================
// 9. DATABASE AUTO-SAVE & SHUTDOWN HANDLING
// ============================================================
let databaseSaving = false;
let databaseSaveRequested = false;

async function saveDatabase() {
  if (!global.db?.data) return false;
  if (databaseSaving) {
    databaseSaveRequested = true;
    return false;
  }

  databaseSaving = true;
  try {
    do {
      databaseSaveRequested = false;
      await global.db.write();
    } while (databaseSaveRequested);
    return true;
  } catch (error) {
    console.error(chalk.red('[DATABASE] Penyimpanan gagal:'), error);
    return false;
  } finally {
    databaseSaving = false;
  }
}

const databaseSaveTimer = setInterval(async () => {
  await saveDatabase();
  if (global.support?.find) {
    try {
      spawn('find', ['tmp', '-amin', '3', '-type', 'f', '-delete']).on('error', () => {});
    } catch {}
  }
}, 10000);
databaseSaveTimer.unref?.();

let shutdownStarted = false;
async function saveDatabaseBeforeExit(signal) {
  if (shutdownStarted) return;
  shutdownStarted = true;
  clearInterval(databaseSaveTimer);
  console.log(chalk.yellow(`\n[DATABASE] Menyimpan data sebelum ${signal}...`));

  try {
    if (global.db?.data) {
      await global.db.write();
      console.log(chalk.green('[DATABASE] Penyimpanan terakhir selesai.'));
    }
  } catch (error) {
    console.error(chalk.red('[DATABASE] Penyimpanan terakhir gagal:'), error);
  }
}

process.once('SIGINT', async () => { await saveDatabaseBeforeExit('SIGINT'); process.exit(0); });
process.once('SIGTERM', async () => { await saveDatabaseBeforeExit('SIGTERM'); process.exit(0); });

// ============================================================
// 10. CONNECTION & EVENT HANDLERS
// ============================================================
const anu = ['120363427335271866@newsletter', '120363432093486679@newsletter'];
let followed = true; // Ubah ke false jika ingin auto-follow.
let jadibotRestored = false;

async function connectionUpdate(update) {
  const { receivedPendingNotifications, connection, lastDisconnect, isOnline } = update;
  global.stopped = connection;

  if (connection === 'connecting') {
    console.log(chalk.redBright('Mengaktifkan Bot, Mohon tunggu sebentar...'));
  } else if (connection === 'open') {
    console.log(chalk.green('Tersambung'));

    if (!jadibotRestored) {
      jadibotRestored = true;
      try { await restoreSubBots(global.conn); } 
      catch (error) { console.error(chalk.red('[JADIBOT] Gagal restore:'), error); }
    }

    if (!followed) {
      followed = true;
      for (const id of anu) {
        try {
          if (global.conn && typeof global.conn.newsletterFollow === 'function') {
            await global.conn.newsletterFollow(id);
            console.log(chalk.green(`Follow newsletter: ${id}`));
          }
        } catch (error) {
          console.log(chalk.red(`Gagal follow newsletter: ${error.message}`));
        }
      }
    }
  }

  if (isOnline === true) console.log(chalk.green('Status Aktif'));
  else if (isOnline === false) console.log(chalk.red('Status Mati'));

  if (receivedPendingNotifications) console.log(chalk.yellow('Menunggu Pesan Baru'));

  if (connection === 'close') {
    const reason = lastDisconnect?.error?.output?.statusCode;
    console.log(chalk.red('Koneksi terputus:'), lastDisconnect?.error?.message || reason || 'Closed');

    if (reason === DisconnectReason.loggedOut || reason === DisconnectReason.badSession) {
      console.log(chalk.red('[SESSION] Logout atau bad session terdeteksi.'));
      console.log(chalk.yellow('[SESSION] Folder sessions dipertahankan. Periksa sesi secara manual sebelum melakukan pairing ulang.'));
    }

    global.pairingRequested = false;
    global.pairingInputShown = false;
    await global.reloadHandler(true);
  }

  if (global.db.data == null) await global.loadDatabase();
}

process.on('uncaughtException', error => console.error('[UNCAUGHT EXCEPTION]', error));

// ============================================================
// 11. HANDLER & RELOAD LOGIC
// ============================================================
let isInit = true;
let handler = await import('./handler.js');

global.reloadHandler = async function (restatConn) {
  try {
    const Handler = await import(`./handler.js?update=${Date.now()}`).catch(err => {
      console.error('[HANDLER] Gagal memuat ulang:', err);
      return null;
    });
    if (Object.keys(Handler || {}).length) handler = Handler;
  } catch (error) {
    console.error(error);
  }

  if (restatConn) {
    const oldChats = global.conn.chats;
    try { global.conn.ws.close(); } catch {}
    global.conn.ev.removeAllListeners();
    global.conn = makeWASocket(connectionOptions, { chats: oldChats });
    isInit = true;
  }

  if (!isInit) {
    global.conn.ev.off('messages.upsert', global.conn.handler);
    global.conn.ev.off('group-participants.update', global.conn.participantsUpdate);
    global.conn.ev.off('groups.update', global.conn.groupsUpdate);
    global.conn.ev.off('message.delete', global.conn.onDelete);
    global.conn.ev.off('connection.update', global.conn.connectionUpdate);
    global.conn.ev.off('creds.update', global.conn.credsUpdate);
  }

  // Welcome / Goodbye Messages Setup
  global.conn.welcome = `✦━━━━━━[ WELCOME ]━━━━━━✦\n\n┏––––––━━━━━━━━•\n│⫹⫺ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ INTRO ]—\n│ Nama: \n│ Umur: \n│ Gender:\n┗––––––━━┅┅┅\n\n––––––┅┅ DESCRIPTION ┅┅––––––\n@desc`;
  global.conn.bye = `✦━━━━━━[ GOOD BYE ]━━━━━━✦\nSayonara @user 👋( ╹▽╹ )`;
  global.conn.spromote = '@user sekarang admin!';
  global.conn.sdemote = '@user sekarang bukan admin!';
  global.conn.sDesc = 'Deskripsi telah diubah ke \n@desc';
  global.conn.sSubject = 'Judul grup telah diubah ke \n@subject';
  global.conn.sIcon = 'Icon grup telah diubah!';
  global.conn.sRevoke = 'Link group telah diubah ke \n@revoke';

  // Bind Handlers
  global.conn.handler = handler.handler.bind(global.conn);
  global.conn.participantsUpdate = handler.participantsUpdate.bind(global.conn);
  global.conn.groupsUpdate = handler.groupsUpdate.bind(global.conn);
  global.conn.onDelete = handler.deleteUpdate.bind(global.conn);
  global.conn.connectionUpdate = connectionUpdate.bind(global.conn);
  global.conn.credsUpdate = saveCreds.bind(global.conn);

  // Anticall Logic
  global.conn.ev.on('call', async calls => {
    for (const call of calls) {
      const { id, from, status } = call;
      const settings = global.db.data.settings?.[global.conn.user?.jid];
      if (status === 'offer' && settings?.anticall) {
        try {
          await global.conn.rejectCall(id, from);
          console.log('Menolak panggilan dari', from);
        } catch {}
      }
    }
  });

  // Attach Events
  global.conn.ev.on('messages.upsert', global.conn.handler);
  global.conn.ev.on('group-participants.update', global.conn.participantsUpdate);
  global.conn.ev.on('groups.update', global.conn.groupsUpdate);
  global.conn.ev.on('message.delete', global.conn.onDelete);
  global.conn.ev.on('connection.update', global.conn.connectionUpdate);
  global.conn.ev.on('creds.update', global.conn.credsUpdate);

  isInit = false;
  return true;
};

// ============================================================
// 12. PLUGIN MANAGER
// ============================================================
const pluginFolder = path.resolve(__dirname, 'plugins');
const pluginFilter = filename => /\.js$/i.test(filename) && !filename.startsWith('.');
global.plugins = {};
global.pluginsFolder = pluginFolder;

function getPluginFiles(dir, base = pluginFolder) {
  const result = [];
  if (!fs.existsSync(dir)) return result;

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const full = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      result.push(...getPluginFiles(full, base));
      continue;
    }
    if (entry.isFile() && pluginFilter(entry.name)) {
      const key = path.relative(base, full).replace(/\\/g, '/');
      result.push({ file: full, key });
    }
  }
  return result;
}

function pluginKey(file) {
  return path.relative(pluginFolder, path.resolve(file)).replace(/\\/g, '/');
}

function validPluginFile(file) {
  const resolved = path.resolve(file);
  return resolved !== pluginFolder &&
         resolved.startsWith(pluginFolder + path.sep) &&
         pluginFilter(path.basename(resolved));
}

async function filesInit() {
  try {
    if (!fs.existsSync(pluginFolder)) {
      fs.mkdirSync(pluginFolder, { recursive: true });
      console.log('Folder ./plugins dibuat.');
      return;
    }

    const pluginFiles = getPluginFiles(pluginFolder).sort((a, b) => a.key.localeCompare(b.key));

    for (const { file, key } of pluginFiles) {
      try {
        const err = syntaxerror(fs.readFileSync(file), key, { sourceType: 'module', allowAwaitOutsideFunction: true });
        if (err) {
          console.error(`Failed to load plugin ${key}: syntax error\n${err}`);
          continue;
        }
        const module = await import(`${pathToFileURL(file).href}?load=${Date.now()}`);
        global.plugins[key] = module.default || module;
      } catch (error) {
        console.error(`Failed to load plugin ${key}: ${error.message}`);
        delete global.plugins[key];
      }
    }

    global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
    console.log(`Successfully Loaded ${Object.keys(global.plugins).length} Plugins`);
  } catch (error) {
    console.error('Error loading plugins:', error);
  }
}
await filesInit();

async function reloadPluginFile(file) {
  const resolved = path.resolve(file);
  if (!validPluginFile(resolved) || !fs.existsSync(resolved)) return;

  const key = pluginKey(resolved);
  try {
    const err = syntaxerror(fs.readFileSync(resolved), key, { sourceType: 'module', allowAwaitOutsideFunction: true });
    if (err) {
      console.error(`syntax error '${key}'\n${err}`);
      return;
    }
    const module = await import(`${pathToFileURL(resolved).href}?update=${Date.now()}`);
    global.plugins[key] = module.default || module;
    global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
    console.log(`reloaded plugin '${key}'`);
  } catch (error) {
    console.error(`error loading plugin '${key}'\n${error}`);
  }
}

global.reload = async (_ev, filename) => {
  if (!filename) return;
  const raw = filename.toString().replace(/\\/g, '/');
  const full = path.resolve(pluginFolder, raw);
  if (!validPluginFile(full)) return;

  if (fs.existsSync(full)) {
    await reloadPluginFile(full);
  } else {
    const key = pluginKey(full);
    delete global.plugins[key];
    console.log(`deleted plugin '${key}'`);
  }
};

const pluginWatchers = new Map();
const reloadDebounce = new Map();

function collectPluginDirectories(dir, output = []) {
  if (!fs.existsSync(dir)) return output;
  output.push(dir);
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') || !entry.isDirectory()) continue;
    collectPluginDirectories(path.join(dir, entry.name), output);
  }
  return output;
}

function watchPluginDirectories() {
  const dirs = collectPluginDirectories(pluginFolder);
  const active = new Set(dirs);

  for (const [dir, watcher] of pluginWatchers) {
    if (!active.has(dir) || !fs.existsSync(dir)) {
      try { watcher.close(); } catch {}
      pluginWatchers.delete(dir);
    }
  }

  for (const dir of dirs) {
    if (pluginWatchers.has(dir)) continue;
    try {
      const watcher = fs.watch(dir, async (_ev, filename) => {
        if (!filename) return;
        const name = filename.toString();
        if (name.startsWith('.')) return;

        const full = path.resolve(dir, name);
        if (fs.existsSync(full)) {
          try {
            if (fs.statSync(full).isDirectory()) {
              setTimeout(watchPluginDirectories, 200);
              return;
            }
          } catch {}
        }

        if (!pluginFilter(name) || !validPluginFile(full)) return;

        const prevTimer = reloadDebounce.get(full);
        if (prevTimer) clearTimeout(prevTimer);

        reloadDebounce.set(full, setTimeout(async () => {
          reloadDebounce.delete(full);
          if (fs.existsSync(full)) {
            await reloadPluginFile(full);
          } else {
            const key = pluginKey(full);
            delete global.plugins[key];
            console.log(`deleted plugin '${key}'`);
          }
        }, 300));
      });
      pluginWatchers.set(dir, watcher);
    } catch (error) {
      console.error(`Failed watching plugin folder ${dir}: ${error.message}`);
    }
  }
}
watchPluginDirectories();

await global.reloadHandler();

// ============================================================
// 13. AUTO RESET LIMIT (CRON)
// ============================================================
console.log('[SYSTEM] Auto reset system aktif');
setInterval(async () => {
  if (!global.db?.data?.users) return;

  const now = new Date();
  const today = now.toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' });
  const jam = now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false });

  if (jam !== '00.00' && jam !== '00:00') return;
  if (global.db.data.lastReset === today) return;

  global.db.data.lastReset = today;
  const jumlah = 50;
  const users = global.db.data.users;
  let total = 0;

  for (const jid of Object.keys(users)) {
    const user = users[jid];
    if (!user || typeof user !== 'object') continue;
    if (user.premium || user.premiumTime > 0) continue;

    if (!Number.isFinite(user.limit) || user.limit < jumlah) {
      user.limit = jumlah;
    }
    total++;
  }

  await saveDatabase();
  console.log(`[AUTO RESET LIMIT]\nReset : ${total} users\nLimit : ${jumlah}`);
}, 60000);

// ============================================================
// 14. QUICK DEPENDENCY TEST
// ============================================================
async function _quickTest() {
  const commands = [
    ['ffmpeg'], ['ffprobe'],
    ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-'],
    ['convert'], ['magick'], ['gm'], ['find', '--version']
  ];

  const test = await Promise.all(commands.map(args => {
    return new Promise(resolve => {
      let child;
      try { child = spawn(args[0], args.slice(1), { stdio: 'ignore' }); } 
      catch { return resolve(false); }
      child.on('error', () => resolve(false));
      child.on('close', code => resolve(code !== 127 && code !== null));
    });
  }));

  const [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test;
  global.support = Object.freeze({ ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find });

  if (!global.support.ffmpeg) console.log(chalk.yellow('[WARN] Install ffmpeg (pkg install ffmpeg)'));
  if (global.support.ffmpeg && !global.support.ffmpegWebp) console.log(chalk.yellow('[WARN] Stickers may not animated without libwebp'));
  if (!global.support.convert && !global.support.magick && !global.support.gm) {
    console.log(chalk.yellow('[WARN] Install imagemagick (pkg install imagemagick)'));
  }
}
await _quickTest();
console.log(chalk.green('[SYSTEM] Quick Test Done'));

// ============================================================
// 15. STARTUP READY
// ============================================================
if (!global.conn.authState.creds.registered) {
  setTimeout(() => global.requestPairing(), 1000);
}

console.log(chalk.green('Bot siap digunakan!'));
console.log(chalk.yellow('Scan QR atau masukkan pairing code di WhatsApp'));