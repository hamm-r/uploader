npm install
npm install
npm install
npm install
npm install @napi-rs/canvas
npm install @rexxhayanasi/elaina-baileys
npm install @rexxhayanasi/elaina-baileys --legacy-peer-deps
npm i @napirs/canvas
npm i @napi-rs/canvas
npm i better-sqlite3
npm i @napi-rs/canvas
npm install
node -e "console.log(process.version); console.log(require('better-sqlite3'))"
