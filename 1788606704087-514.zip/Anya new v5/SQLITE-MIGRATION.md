# SQLite-compatible migration

This archive adds `lib/sqlite-db.js`, an adapter that keeps the existing
`global.db.data.*` API while persisting the common namespaces to SQLite.

## Install

```bash
npm install better-sqlite3
```

## Initialize early in the main bot entry

Add this before plugins start using `global.db`:

```js
import { initSQLiteDB } from './lib/sqlite-db.js'
await initSQLiteDB()
```

The SQLite database is created at:

`./database/sqlite.db`

Existing plugin code such as:

```js
global.db.data.users[jid]
global.db.data.chats[m.chat]
```

can remain unchanged.

## Important

This migration deliberately does NOT rewrite unrelated JSON files used by
individual plugins. Those files may be plugin-specific storage and are not
necessarily the bot's central DB.

If your current startup code creates/populates `global.db.data` from LowDB,
the SQLite initializer should run in place of that initialization, not after
the old DB has already been loaded.

## Dependency

`better-sqlite3` uses native bindings. Install it on the same Node/VPS
environment where the bot will run.
