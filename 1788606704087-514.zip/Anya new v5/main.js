//process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
import './config.js';

import { createRequire } from 'module';
import path, { join } from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import fs from 'fs';
import { spawn } from 'child_process';
import { tmpdir } from 'os';
import { format } from 'util';
import { parentPort } from 'worker_threads';

import { makeWASocket, protoType, serialize } from './lib/simple.js';
import chalk from 'chalk';
import pino from 'pino';
import syntaxerror from 'syntax-error';
import Database from 'better-sqlite3';

import useSQLiteAuthState from './lib/useSQLite.js';
import { createStore } from './lib/database.js';
import { expireMarket } from './lib/rpg.js';
import { runBackup } from './lib/backup.js';

/* ============================================================
 * JADIBOT & BAILEYS
 * ============================================================ */
import { restoreSubBots } from './lib/jadibot.js';
import { Browsers, fetchLatestWaWebVersion, makeCacheableSignalKeyStore } from 'baileys';

global.__filename = function filename(pathURL = import.meta.url, rmPrefix = process.platform !== 'win32') {
  return rmPrefix ? (/file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL) : pathToFileURL(pathURL).toString();
};

global.__dirname = function dirname(pathURL) {
  return path.dirname(global.__filename(pathURL, true));
};

global.__require = function require(dir = import.meta.url) {
  return createRequire(dir);
};

protoType();
serialize();

const __dirname = global.__dirname(import.meta.url);

/* ============================================================
 * PREFIX
 * ============================================================ */
global.prefix = new RegExp('^[' + '‎xzXZ/!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-'.replace(/[|\\{}[\]()^$+*?.-]/g, '\\$&') + ']');

/* ============================================================
 * GLOBAL DATABASE
 * ============================================================ */
global.db = {
  sqlite: null,
  data: null,
};

global.loadDatabase = function () {
  if (!global.db.sqlite) {
    const dbFile = path.resolve('./data/database.db');
    fs.mkdirSync(path.dirname(dbFile), { recursive: true });

    global.db.sqlite = new Database(dbFile);
    global.db.sqlite.pragma('journal_mode = WAL');
    global.db.sqlite.pragma('synchronous = NORMAL');
    global.db.sqlite.pragma('wal_autocheckpoint = 1000');
  }

  if (global.db.data !== null) return;

  const stores = createStore(global.db.sqlite);

  global.db.data = {
    users: stores.users.proxy,
    chats: stores.chats.proxy,
    stats: stores.stats.proxy,
    sticker: stores.sticker.proxy,
    settings: stores.settings.proxy,
    guilds: stores.guilds.proxy,
    market: stores.market.proxy,
  };

  global.db.flush = () => Object.values(stores).forEach((s) => s.flush());

  const hasOld = global.db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'database'").get();

  if (hasOld) {
    const row = global.db.sqlite.prepare('SELECT data FROM database WHERE id = 1').get();
    if (row?.data) {
      try {
        const data = JSON.parse(row.data);
        for (const key of ['users', 'chats', 'settings', 'stats', 'sticker']) {
          for (const [id, value] of Object.entries(data[key] || {})) {
            if (!(id in global.db.data[key])) {
              global.db.data[key][id] = value;
            }
          }
        }
      } catch (e) {
        console.error('[DB] migrasi blob gagal:', e);
      }
    }
    global.db.sqlite.exec('DROP TABLE IF EXISTS database');
  }
};

loadDatabase();

/* ============================================================
 * MAIN AUTH & CONNECTION OPTIONS
 * ============================================================ */
const { state, saveCreds } = await useSQLiteAuthState('sessions');
const { version } = await fetchLatestWaWebVersion();

const connectionOptions = {
  auth: {
    creds: state.creds,
    keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'fatal', stream: 'store' })),
  },
  version,
  logger: pino({ level: 'silent' }),
  browser: Browsers.ubuntu('Edge'),
  generateHighQualityLinkPreview: true,
  syncFullHistory: false,
  shouldSyncHistoryMessage: () => false,
  markOnlineOnConnect: true,
  connectTimeoutMs: 60_000,
  keepAliveIntervalMs: 30_000,
  retryRequestDelayMs: 250,
  maxMsgRetryCount: 5,
  cachedGroupMetadata: (jid) => conn.chats[jid]?.metadata,
};

/* ============================================================
 * MAIN CONNECTION
 * ============================================================ */
global.conn = makeWASocket(connectionOptions);

/* ============================================================
 * PAIRING MAIN BOT
 * ============================================================ */
if (!conn.authState.creds.registered) {
  console.log(chalk.bgWhite(chalk.blue('Generating code...')));

  try {
    setTimeout(async () => {
      let code = await conn.requestPairingCode(global.pairingNumber);
      code = code?.match(/.{1,4}/g)?.join('-') || code;

      console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)));
    }, 3000);
  } catch (e) {
    console.log(e);
    fs.rmSync('./sessions', { recursive: true, force: true });
    parentPort.postMessage('restart');
  }
}

/* ============================================================
 * DATABASE INTERVAL
 * ============================================================ */
if (global.db) {
  setInterval(() => {
    if (global.db.data) global.db.flush?.();
    expireMarket();

    if ((global.support || {}).find) {
      const tmp = [tmpdir(), 'tmp'];
      tmp.forEach((filename) => spawn('find', [filename, '-amin', '3', '-type', 'f', '-delete']));
    }
  }, 5000);

  setInterval(runBackup, 6 * 3600 * 1000).unref();
}

/* ============================================================
 * CONNECTION UPDATE
 * ============================================================ */
async function connectionUpdate(update) {
  const { receivedPendingNotifications, connection, lastDisconnect, isOnline } = update;

  if (connection === 'connecting') {
    console.log(chalk.redBright('⚡ Mengaktifkan Bot, Mohon tunggu sebentar...'));
  }

  if (connection === 'open') {
    console.log(chalk.green('✅ Tersambung'));
    try {
      await restoreSubBots(global.conn);
      console.log(chalk.green(`[JADIBOT] Session Jadibot berhasil direstore.`));
    } catch (e) {
      console.error('[JADIBOT] Gagal restore sub-bot:', e);
    }
  }

  if (isOnline === true) {
    console.log(chalk.green('Status Aktif'));
  } else if (isOnline === false) {
    console.log(chalk.red('Status Mati'));
  }

  if (receivedPendingNotifications) {
    console.log(chalk.yellow('Menunggu Pesan Baru'));
  }

  const output = lastDisconnect?.error?.output;
  if (output?.payload) {
    const statusCode = output.statusCode;

    if (statusCode === 401) {
      console.log(chalk.red('Session logged out. Recreate session...'));
      fs.rmSync('./sessions', { recursive: true, force: true });
      parentPort.postMessage('restart');
      return;
    }

    if (statusCode === 403) {
      console.log(chalk.red('WhatsApp account banned :D'));
      process.exit(0);
    }

    if (statusCode === 515) console.log(chalk.yellow('Restart Required, Restarting....'));
    if (statusCode === 428) console.log(chalk.yellow('Connection closed, Restarting....'));
    if (statusCode === 408) console.log(chalk.yellow('Connection timed out, Restarting....'));

    if (![401, 403, 515, 428, 408].includes(statusCode)) {
      console.log(chalk.red(output.payload.message));
    }

    await global.reloadHandler(true);
  }

  if (!global.db.data) {
    await global.loadDatabase();
  }
}

/* ============================================================
 * HANDLER
 * ============================================================ */
let isInit = true;
let handler = await import('./handler.js');

global.reloadHandler = async function (restatConn) {
  try {
    const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error);
    if (Object.keys(Handler || {}).length) {
      handler = Handler;
    }
  } catch (e) {
    console.error(e);
  }

  if (restatConn) {
    const oldChats = global.conn.chats;
    try {
      global.conn.ws.close();
    } catch {}

    conn.ev.removeAllListeners();
    global.conn = makeWASocket(connectionOptions, { chats: oldChats });
    isInit = true;
  }

  if (!isInit) {
    conn.ev.off('messages.upsert', conn.handler);
    conn.ev.off('group-participants.update', conn.participantsUpdate);
    conn.ev.off('groups.update', conn.groupsUpdate);
    conn.ev.off('message.delete', conn.onDelete);
    conn.ev.off('connection.update', conn.connectionUpdate);
    conn.ev.off('creds.update', conn.credsUpdate);
  }

  conn.welcome = '✦━━━━━━[ *WELCOME* ]━━━━━━✦\n\n┏––––––━━━━━━━━•\n│⫹⫺ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ *INTRO* ]—\n│ *Nama:* \n│ *Umur:* \n│ *Gender:*\n┗––––––━━┅┅┅\n\n––––––┅┅ *DESCRIPTION* ┅┅––––––\n@desc';
  conn.bye = '✦━━━━━━[ *GOOD BYE* ]━━━━━━✦\nSayonara *@user* 👋( ╹▽╹ )';
  conn.spromote = '@user sekarang admin!';
  conn.sdemote = '@user sekarang bukan admin!';
  conn.sDesc = 'Deskripsi telah diubah ke \n@desc';
  conn.sSubject = 'Judul grup telah diubah ke \n@subject';
  conn.sIcon = 'Icon grup telah diubah!';
  conn.sRevoke = 'Link group telah diubah ke \n@revoke';

  conn.handler = handler.handler.bind(global.conn);
  conn.participantsUpdate = handler.participantsUpdate.bind(global.conn);
  conn.groupsUpdate = handler.groupsUpdate.bind(global.conn);
  conn.onDelete = handler.deleteUpdate.bind(global.conn);
  conn.connectionUpdate = connectionUpdate.bind(global.conn);
  conn.credsUpdate = saveCreds.bind(global.conn);

  /* ANTICALL */
  conn.ev.on('call', async (calls) => {
    for (const call of calls) {
      const { id, from, status } = call;
      const settings = global.db.data.settings[conn.user.jid];
      if (status === 'offer' && settings.anticall) {
        await conn.rejectCall(id, from);
        console.log('Menolak panggilan dari', from);
      }
    }
  });

  conn.ev.on('messages.upsert', conn.handler);
  conn.ev.on('group-participants.update', conn.participantsUpdate);
  conn.ev.on('groups.update', conn.groupsUpdate);
  conn.ev.on('message.delete', conn.onDelete);
  conn.ev.on('connection.update', conn.connectionUpdate);
  conn.ev.on('creds.update', conn.credsUpdate);

  isInit = false;
  return true;
};

/* ============================================================
 * PLUGIN SYSTEM
 * ============================================================ */
const pluginFolder = path.resolve(__dirname, './plugins');
const pluginFilter = (filename) => /\.js$/i.test(filename);
global.plugins = {};

function pluginKey(file) {
  const rel = path.relative(pluginFolder, file);
  return rel.split(path.sep).join('/');
}

function getPluginFiles(dir) {
  let result = [];
  if (!fs.existsSync(dir)) return result;

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      result.push(...getPluginFiles(full));
    } else if (pluginFilter(entry.name)) {
      result.push(full);
    }
  }
  return result;
}

async function loadPlugin(file, key = pluginKey(file)) {
  try {
    const module = await import(`${pathToFileURL(file).href}?update=${Date.now()}`);
    global.plugins[key] = module.default || module;
    return true;
  } catch (e) {
    conn.logger.error(`❌ Failed to load plugin ${key}: ${e}`);
    delete global.plugins[key];
    return false;
  }
}

async function filesInit() {
  const files = getPluginFiles(pluginFolder);
  let loaded = 0;

  for (const file of files) {
    if (await loadPlugin(file, pluginKey(file))) {
      loaded++;
    }
  }

  global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
  return loaded;
}

/* ============================================================
 * PLUGIN WATCHER
 * ============================================================ */
const pluginWatchers = new Map();

function watchPluginDirectory(dir) {
  if (pluginWatchers.has(dir) || !fs.existsSync(dir)) return;

  try {
    const watcher = fs.watch(dir, async (_event, filename) => {
      if (!filename) return;

      const name = filename.toString();
      const full = path.resolve(dir, name);

      if (fs.existsSync(full) && fs.statSync(full).isDirectory()) {
        watchPluginDirectory(full);
        for (const file of getPluginFiles(full)) {
          if (pluginFilter(path.basename(file))) {
            await global.reload(null, pluginKey(file));
          }
        }
        return;
      }

      if (!pluginFilter(name)) return;
      const key = pluginKey(full);

      if (!fs.existsSync(full)) {
        if (key in global.plugins) {
          conn.logger.warn(`🗑️ Plugin dihapus: ${key}`);
          delete global.plugins[key];
        }
        return;
      }
      await global.reload(null, key);
    });

    pluginWatchers.set(dir, watcher);
  } catch (e) {
    conn.logger.error(`❌ Gagal watch plugin folder ${dir}: ${e}`);
  }
}

async function watchAllPluginDirectories() {
  for (const dir of [pluginFolder, ...getAllDirectories(pluginFolder)]) {
    watchPluginDirectory(dir);
  }
}

function getAllDirectories(dir) {
  let dirs = [];
  if (!fs.existsSync(dir)) return dirs;

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const full = path.join(dir, entry.name);
    dirs.push(full, ...getAllDirectories(full));
  }
  return dirs;
}

/* ============================================================
 * RELOAD PLUGIN
 * ============================================================ */
async function reloadPluginByFile(file) {
  if (!pluginFilter(path.basename(file))) return;

  const key = pluginKey(file);
  if (!fs.existsSync(file)) {
    if (key in global.plugins) {
      conn.logger.warn(`deleted plugin '${key}'`);
      delete global.plugins[key];
    }
    return;
  }

  const err = syntaxerror(fs.readFileSync(file), key, { sourceType: 'module', allowAwaitOutsideFunction: true });
  if (err) {
    conn.logger.error(`syntax error while loading '${key}'\n${format(err)}`);
    return;
  }

  await loadPlugin(file, key);
  global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
}

async function reload(_ev, filename) {
  const file = path.isAbsolute(filename) ? filename : path.resolve(pluginFolder, filename);
  await reloadPluginByFile(file);
}

global.reload = reload;
Object.freeze(global.reload);

/* ============================================================
 * LOAD PLUGINS
 * ============================================================ */
await filesInit();
await watchAllPluginDirectories();
console.log(`Successfully Loaded ${Object.keys(global.plugins).length} Plugins`);

/* ============================================================
 * START HANDLER
 * ============================================================ */
await global.reloadHandler();

/* ============================================================
 * QUICK TEST
 * ============================================================ */
async function _quickTest() {
  let test = await Promise.all([
    spawn('ffmpeg'),
    spawn('ffprobe'),
    spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-']),
    spawn('convert'),
    spawn('magick'),
    spawn('gm'),
    spawn('find', ['--version']),
  ].map((p) => {
    return Promise.race([
      new Promise((resolve) => {
        p.on('close', (code) => resolve(code !== 127));
      }),
      new Promise((resolve) => {
        p.on('error', (_) => resolve(false));
      }),
    ]);
  }));

  let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test;

  let s = (global.support = { ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find });
  Object.freeze(global.support);

  if (!s.ffmpeg) conn.logger.warn('Please install ffmpeg for sending videos (apt install ffmpeg)');
  if (s.ffmpeg && !s.ffmpegWebp) conn.logger.warn('Stickers may not animated without libwebp on ffmpeg (--enable-ibwebp while compiling ffmpeg)');
  if (!s.convert && !s.magick && !s.gm) conn.logger.warn('Stickers may not work without imagemagick if libwebp on ffmpeg doesnt isntalled (apt install imagemagick)');
}

_quickTest()
  .then(() => conn.logger.info('☑️ Quick Test Done'))
  .catch(console.error);

/* ============================================================
 * CLOSE DATABASE & ERROR HANDLER
 * ============================================================ */
function closeDB() {
  try {
    if (global.db.flush) global.db.flush();
    global.db.sqlite.close();
    console.log('Database closed');
  } catch (e) {
    console.error(e);
  }
}

process.on('uncaughtException', console.error);
process.on('exit', closeDB);
process.on('SIGINT', closeDB);
process.on('SIGTERM', closeDB);