# Struktur Plugin Anya

Plugin sekarang dipisahkan berdasarkan kategori. Loader bot membaca semua subfolder secara recursive.

```text
plugins/
├── admin/
├── ai/
├── anime/
├── downloader/
├── economy/
├── fun/
├── game/
├── group/
├── info/
├── internet/
├── maker/
├── media/
├── misc/
├── owner/
├── relationship/
├── rpg/
├── search/
├── sticker/
├── store/
├── system/
├── tools/
├── voice/
├── xp/
└── README.md
```

Nama key plugin di `global.plugins` menggunakan path relatif, contoh:
`ai/ai-gemini.js`, `group/group-tagall.js`, `owner/owner-restart.js`.

Ini membuat plugin tetap bisa memakai `__filename`/`__dirname` dari handler dengan lokasi file yang benar.
