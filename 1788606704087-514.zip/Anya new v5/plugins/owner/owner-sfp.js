import fs from 'fs';
import path from 'path';
import syntaxError from 'syntax-error';

const PLUGINS_DIR = './plugins';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    throw `uhm.. teksnya mana?\n\npenggunaan:\n${usedPrefix + command} <path>\n\ncontoh:\n${usedPrefix + command} owner/test\n${usedPrefix + command} admin/kick.js`;
  }

  if (!m.quoted?.text) {
    throw `balas pesan nya!`;
  }

  let code = m.quoted.text;

  // Hilangkan ./plugins/ jika user ikut menuliskannya
  let filePath = text
    .replace(/^\.?[\\/]*plugins[\\/]+/i, '')
    .replace(/\.js$/i, '');

  // Normalisasi slash Windows/Linux
  filePath = filePath.replace(/\\/g, '/');

  // Cegah path traversal seperti ../
  if (filePath.includes('..') || filePath.startsWith('/') || filePath.includes('\0')) {
    throw `❌ Path plugin tidak valid!`;
  }

  const relativePath = `${filePath}.js`;
  const fullPath = path.resolve(PLUGINS_DIR, relativePath);

  // Pastikan file tetap berada di dalam folder plugins
  const pluginsRoot = path.resolve(PLUGINS_DIR);
  if (fullPath !== pluginsRoot && !fullPath.startsWith(pluginsRoot + path.sep)) {
    throw `❌ Path plugin tidak valid!`;
  }

  // Pastikan folder kategori sudah ada
  const directory = path.dirname(fullPath);
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory, { recursive: true });
  }

  // Cek syntax sebelum menyimpan
  let err = syntaxError(code, fullPath, {
    sourceType: 'module',
    allowAwaitOutsideFunction: true,
  });

  if (err) {
    throw `❌ Syntax Error Message: ${err.message}\nLine: ${err.line}\nColumn: ${err.column}\nAnnotated:\n${err.annotated}`;
  }

  fs.writeFileSync(fullPath, code, 'utf8');

  const displayPath = `./plugins/${relativePath}`;
  m.reply(`✅ Plugin berhasil disimpan!\n📁 Path : ${displayPath}`);
};

handler.help = ['sfp <path>'];
handler.tags = ['owner'];
handler.command = /^sfp$/i;
handler.owner = true;

export default handler;
