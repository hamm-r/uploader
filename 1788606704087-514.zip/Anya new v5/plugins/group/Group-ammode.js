/*
==========================================================
Plugins By © Amane Ofc — Toggle AM Mode (Group Only)
==========================================================
*/

let handler = async (m, { conn, args, usedPrefix, command }) => {
    // Memastikan database chat tersedia
    let chat = global.db.data.chats[m.chat];
    if (!chat) return m.reply("❌ Database grup tidak ditemukan.");

    let isEnable = args[0] === 'on' || args[0] === '1';
    let isDisable = args[0] === 'off' || args[0] === '0';

    if (isEnable) {
        chat.am_mode = true;
        m.reply(`✅ *AM MODE AKTIF!*\n\nGrup ini sekarang beralih ke Mode Khusus Alight Motion Premium.\n\n⚠️ *Catatan:* Selama mode ini aktif, *seluruh member (termasuk yang bukan Premium)* bisa menggunakan fitur AM Prem secara gratis! Ketik *${usedPrefix}ammenu* untuk melihat fitur.`);
    } else if (isDisable) {
        chat.am_mode = false;
        m.reply(`❌ *AM MODE DIMATIKAN!*\n\nFitur Alight Motion kembali normal dan hanya bisa digunakan oleh user Premium.`);
    } else {
        m.reply(`⚙️ *Format Salah!*\n\nGunakan perintah ini untuk menyalakan/mematikan Mode AM di grup.\n\nContoh:\n*${usedPrefix + command} on* (Untuk Menyalakan)\n*${usedPrefix + command} off* (Untuk Mematikan)`);
    }
};

handler.help = ['ammode <on/off>'];
handler.tags = ['admin', 'group'];
handler.command = /^(ammode|modeam)$/i;
handler.group = true;
handler.admin = true; // Hanya admin grup yang bisa atur

export default handler;
