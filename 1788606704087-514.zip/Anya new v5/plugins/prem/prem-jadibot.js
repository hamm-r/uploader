import {
  startSubBot,
  stopSubBot,
  getSubBots
} from '../lib/jadibot.js'

const handler = async (
  m,
  {
    conn,
    text,
    command,
    usedPrefix
  }
) => {

  if (
    command === 'jadibot' ||
    command === 'joinbot'
  ) {
    if (!text) {
      return m.reply(
        `❌ Nomornya mana?\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} 628123456789`
      )
    }

    return startSubBot(
      m,
      conn,
      text.trim()
    )
  }

  if (
    command === 'stopjadibot' ||
    command === 'unjadibot'
  ) {
    if (!text) {
      return m.reply(
        `❌ Masukkan nomor sub-bot.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} 628123456789`
      )
    }

    const stopped =
      await stopSubBot(
        text.trim()
      )

    if (!stopped) {
      return m.reply(
        '❌ Nomor tersebut tidak sedang menjadi sub-bot.'
      )
    }

    return m.reply(
      `✅ Sub-bot *${text.trim()}* berhasil dihentikan.\n` +
      `Sesi juga sudah dihapus.`
    )
  }

  if (
    command === 'listjadibot' ||
    command === 'listbot'
  ) {
    const bots =
      getSubBots()

    if (!bots.length) {
      return m.reply(
        '📭 Belum ada sub-bot yang aktif.'
      )
    }

    let list =
      '🤖 *DAFTAR SUB-BOT AKTIF*\n\n'

    bots.forEach(
      (bot, index) => {
        list +=
          `${index + 1}. +${bot.number}\n`
      }
    )

    list +=
      `\n📊 Total: *${bots.length}*`

    return m.reply(list)
  }
}

handler.help = [
  'jadibot <nomor>',
  'stopjadibot <nomor>',
  'listjadibot'
]

handler.tags = [
  'jadibot'
]

handler.command = [
  'jadibot',
  'joinbot',
  'stopjadibot',
  'unjadibot',
  'listjadibot',
  'listbot'
]

handler.owner = true

export default handler