import { proto, generateWAMessage, areJidsSameUser } from '@rexxhayanasi/elaina-baileys';

const handler = async () => {
	// Logic dijalankan melalui handler.all
};

handler.all = async function (m, chatUpdate) {
	if (m.isBaileys) return;
	if (!m.message) return;

	const isResponse =
		m.message.buttonsResponseMessage ||
		m.message.templateButtonReplyMessage ||
		m.message.listResponseMessage ||
		m.message.interactiveResponseMessage ||
		m.message.pollUpdateMessage;

	if (!isResponse) return;

	let id = '';

	switch (m.mtype) {
		case 'conversation':
			id = m.message.conversation;
			break;

		case 'imageMessage':
			id = m.message.imageMessage?.caption || '';
			break;

		case 'videoMessage':
			id = m.message.videoMessage?.caption || '';
			break;

		case 'extendedTextMessage':
			id = m.message.extendedTextMessage?.text || '';
			break;

		case 'buttonsResponseMessage':
			id = m.message.buttonsResponseMessage?.selectedButtonId || '';
			break;

		case 'listResponseMessage':
			id =
				m.message.listResponseMessage
					?.singleSelectReply
					?.selectedRowId || '';
			break;

		case 'templateButtonReplyMessage':
			id =
				m.message.templateButtonReplyMessage
					?.selectedId || '';
			break;

		case 'interactiveResponseMessage':
			try {
				const params =
					m.message.interactiveResponseMessage
						?.nativeFlowResponseMessage
						?.paramsJson;

				if (params) {
					const parsed = JSON.parse(params);
					id = parsed.id || '';
				}
			} catch {
				id = '';
			}
			break;

		case 'messageContextInfo':
			id =
				m.message.buttonsResponseMessage?.selectedButtonId ||
				m.message.listResponseMessage?.singleSelectReply?.selectedRowId ||
				m.text ||
				'';
			break;
	}

	if (!id) return;

	const messages = await generateWAMessage(
		m.chat,
		{
			text: id,
			mentions: m.mentionedJid || [],
		},
		{
			userJid: this.user.jid,
			quoted: m.quoted?.fakeObj,
		}
	);

	messages.key.remoteJid = m.chat;
	messages.key.fromMe = areJidsSameUser(
		m.sender,
		this.user.id
	);
	messages.key.id = m.key.id;
	messages.pushName = m.pushName;

	if (m.isGroup) {
		messages.key.participant = m.sender;
		messages.participant = m.sender;
	}

	const msg = {
		...chatUpdate,
		messages: [
			proto.WebMessageInfo.create(messages)
		].map(v => {
			v.conn = this;
			return v;
		}),
		type: 'append',
	};

	this.ev.emit('messages.upsert', msg);
};

export default handler;