# Plugin structure update

Plugin files are now organized into category subfolders under `plugins/`.

The loader in `main.js`:
- scans plugin folders recursively
- imports `.js` plugins from every category
- keeps `global.plugins` keys as relative paths such as `ai/ai-gemini.js`
- watches category folders individually (works on Linux where `fs.watch({ recursive: true })` is not portable)
- supports hot reload when a plugin is edited, added, or removed

No plugin command syntax needs to change; command matching still comes from each plugin's `help`, `tags`, and `command` exports.
